---
title: Three-phase motor, star-delta, forward and reverse
simulation: motor
level: 3
symbols:
- %I0.0 Forward (PB)
- %I0.1 Reverse (PB)
- %I0.2 Stop (NC, PB)
- %I0.3 Overload relay OK
- %I0.4 Motor stopped
- %Q0.0 KM1 forward
- %Q0.1 KM2 reverse
- %Q0.2 KM3 star
- %Q0.3 KM4 delta
- %Q0.4 Run lamp
- %Q0.5 Fault lamp
---
# 25. Three-phase motor, star-delta, forward and reverse

**Goal:** start a three-phase motor in star and switch it to delta, in either direction, protected by
an overload relay, the way a real motor starter does it.

## Inputs and outputs (Three-phase motor simulation)

| Address | Device |
| --- | --- |
| %I0.0 | Forward (pushbutton) |
| %I0.1 | Reverse (pushbutton) |
| %I0.2 | Stop (pushbutton, **normally closed**) |
| %I0.3 | Overload relay OK (**normally closed** contact: FALSE when tripped) |
| %I0.4 | Motor stopped (zero-speed sensor, below 30 rpm) |
| %Q0.0, %Q0.1 | KM1 line contactor forward, KM2 line contactor reverse |
| %Q0.2, %Q0.3 | KM3 star, KM4 delta |
| %Q0.4 | Run lamp |
| %Q0.5 | Fault lamp |

## Requirements

1. Forward starts the motor in star (KM1 + KM3) and switches to delta (KM1 + KM4) a few seconds
   later; Reverse does the same with KM2.
2. It never starts straight in delta.
3. Star and delta are never on together; forward and reverse are never on together.
4. Reverse is ignored while the motor runs forward (and the other way round): stop first, and
   start the other way only once the motor has stopped.
5. Stop stops the motor.
6. An overload trip drops every contactor and lights the fault lamp; the motor cannot start until
   the relay is reset.
7. The run lamp is on while the motor runs.

## Hints

- Seal in each line contactor like a motor starter; put Stop, the overload contact and an NC
  contact of the other direction in series.
- Only accept a start while "Motor stopped" is TRUE.
- One timer started by either line contactor: star while it runs, delta when it is done, each with
  an NC contact of the other.

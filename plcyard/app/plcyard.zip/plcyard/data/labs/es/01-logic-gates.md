---
title: Compuertas lógicas con contactos
simulation: io
level: 1
symbols:
- %I0.0 Entrada A
- %I0.1 Entrada B
- %I0.2 Entrada C
- %I0.3 Entrada D
- %I0.4 Entrada E
- %I0.5 Entrada F
- %I0.6 Entrada G
- %Q0.0 Salida AND
- %Q0.1 Salida OR
- %Q0.2 Salida NOT
- %Q0.3 Salida XOR
---
# 1. Compuertas lógicas con contactos

**Objetivo:** construir AND, OR, NOT y XOR con contactos `XIC`/`XIO` en serie y en paralelo.

## Entradas y salidas

| Dirección | Uso |
| --- | --- |
| %I0.0, %I0.1 | Entradas de la compuerta AND |
| %I0.2, %I0.3 | Entradas de la compuerta OR |
| %I0.4 | Entrada del inversor |
| %I0.5, %I0.6 | Entradas de la XOR |
| %Q0.0 … %Q0.3 | AND, OR, NOT, XOR |

## Requisitos

1. %Q0.0 se enciende solo cuando %I0.0 **y** %I0.1 están cerrados.
2. %Q0.1 se enciende cuando %I0.2 **o** %I0.3 está cerrado.
3. %Q0.2 se enciende cuando %I0.4 está **abierto**.
4. %Q0.3 se enciende cuando %I0.5 y %I0.6 son **diferentes**.

## Pistas

- Contactos en serie = AND; ramas en paralelo = OR; `XIO` = NOT.
- XOR necesita dos ramas: (A y no B) o (no A y B).

## Cómo probarlo

Descarga, pon el PLC en RUN y recorre la tabla de verdad de cada compuerta con los interruptores.

---
title: Arranque/parada con enclavamiento
simulation: io
level: 1
symbols:
- %I0.0 Inicio (NO)
- %I0.1 Parada (NC)
- %Q0.0 Motor
- %Q0.1 Luz de marcha
- %Q0.2 Luz de detenido
---
# 2. Arranque/parada con enclavamiento

**Objetivo:** mantener un motor en marcha después de soltar el pulsador de inicio.

## Entradas y salidas

| Dirección | Dispositivo | Tipo |
| --- | --- | --- |
| %I0.0 | Inicio | normalmente abierto |
| %I0.1 | Parada | **normalmente cerrado** |
| %Q0.0 | Motor | |
| %Q0.1 | Luz de marcha | |
| %Q0.2 | Luz de detenido | |

## Requisitos

1. Cerrar y abrir Inicio deja el motor en marcha.
2. Abrir Parada (pulsarlo) apaga el motor, aunque Inicio siga cerrado.
3. Si se corta el cable de Parada, el motor también debe apagarse.
4. La luz de marcha sigue al motor; la luz de detenido está encendida mientras el motor está apagado.

## Pistas

- Parada es NC: cuando no está pulsado entrega un 1. ¿Qué instrucción lo examina?
- El propio contacto del motor, en paralelo con Inicio, es el enclavamiento.

## Piénsalo

¿Qué le pasa al motor si pasas el PLC a PGM y de vuelta a RUN? ¿Por qué?

---
title: Motor reversible con enclavamiento mutuo
simulation: io
level: 2
symbols:
- %I0.0 Adelante (NO)
- %I0.1 Atrás (NO)
- %I0.2 Parada (NC)
- %Q0.0 Contactor de adelante
- %Q0.1 Contactor de atrás
---
# 3. Motor reversible con enclavamiento mutuo

**Objetivo:** hacer girar un motor en dos sentidos sin que ambos contactores estén encendidos a la vez.

## Requisitos

1. Adelante (%I0.0) arranca y enclava %Q0.0; Atrás (%I0.1) arranca y enclava %Q0.1.
2. Parada (%I0.2, NC) detiene a cualquiera de los dos.
3. %Q0.0 y %Q0.1 **nunca** deben estar encendidos al mismo tiempo.
4. Para cambiar de sentido primero debes parar: pulsar Atrás mientras gira hacia adelante no hace nada.

## Pistas

- El escalón de cada contactor incluye un contacto `XIO` del otro (enclavamiento mutuo).

---
title: Encendido y apagado con un solo botón
simulation: io
level: 2
symbols:
- %I0.0 Botón (NO, pulsador)
- %Q0.0 Lámpara
---
# 4. Encendido y apagado con un solo botón

**Objetivo:** usar un disparo único (`ONS`) para que cada pulsación cambie el estado de una lámpara.

## Requisitos

1. Cada pulsación de %I0.0 cambia %Q0.0 (encendida ↔ apagada).
2. Mantener el botón pulsado **no** debe hacer parpadear la lámpara.

## Pistas

- `ONS` entrega un pulso de un solo escaneo cuando su escalón pasa de falso a verdadero.
- Con ese pulso y el estado actual de la lámpara puedes armar un flip-flop de dos ramas.

---
title: Luz intermitente con temporizadores
simulation: io
level: 2
symbols:
- %I0.0 Habilitación
- %Q0.0 Luz intermitente
---
# 5. Luz intermitente con temporizadores

**Objetivo:** encadenar dos temporizadores TON para generar una señal periódica.

## Requisitos

1. Con %I0.0 cerrado, %Q0.0 está encendida 1 s y apagada 1 s, repitiéndose.
2. Abrir %I0.0 apaga la luz y reinicia el ciclo.

## Pistas

- Declara dos tags TIMER (Ctrl+T abre la lista de tags). Los presets están en milisegundos: 1000 es
  1 s, y T#1s también funciona.
- El bit DN del segundo temporizador puede reiniciar el primero.
- Abre un temporizador en la lista de tags para ver sus bits EN, TT y DN a baja velocidad.

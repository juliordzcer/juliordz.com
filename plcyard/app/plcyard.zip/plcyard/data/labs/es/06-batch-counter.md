---
title: Contador de lotes con display
simulation: io
level: 2
symbols:
- %I0.0 Sensor de pieza (NO, pulsador)
- %I0.1 Reiniciar lote (NO, pulsador)
- %Q0.0 Lote completo
---
# 6. Contador de lotes con display

**Objetivo:** contar piezas con CTU, señalizar un lote completo y mostrar el conteo en el display BCD.

## Requisitos

1. Cada pulso en %I0.0 cuenta una pieza (un pulso = una pieza, sin importar cuánto dure).
2. Al llegar a 5 piezas, %Q0.0 (lote completo) se enciende.
3. %I0.1 reinicia el conteo y apaga %Q0.0.
4. El display %QW4 siempre muestra el número de piezas.

## Pistas

- El display espera BCD: convierte el acumulador con `TOD`.

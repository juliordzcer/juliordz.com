---
title: Clasificación por rango con comparadores
simulation: io
level: 2
symbols:
- %Q0.0 Bajo
- %Q0.1 Normal
- %Q0.2 Alto
---
# 7. Clasificación por rango con comparadores

**Objetivo:** leer un número de los thumbwheels (%IW4, BCD) y clasificarlo.

## Requisitos

1. Convierte el valor de %IW4 a binario en un tag INT (por ejemplo `Value`).
2. %Q0.0 (Bajo) cuando el valor es menor que 100.
3. %Q0.1 (Normal) cuando está entre 100 y 500, inclusive.
4. %Q0.2 (Alto) cuando es mayor que 500.
5. Solo una de las tres salidas puede estar encendida.

## Pistas

- `FRD` convierte de BCD a binario.
- `LIM` resuelve "entre" en una sola instrucción.

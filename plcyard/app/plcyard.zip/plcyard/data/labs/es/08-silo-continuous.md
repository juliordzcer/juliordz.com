---
title: Llenado continuo en la línea del silo
simulation: silo
level: 2
---
# 8. Llenado continuo en la línea del silo

**Objetivo:** controlar un proceso real: cinta transportadora, sensor de posición, válvula y sensor de nivel.

## Entradas y salidas (simulación Silo)

| Dirección | Dispositivo |
| --- | --- |
| %I0.0 | Marcha (pulsador NO) |
| %I0.1 | Paro (pulsador NC) |
| %I0.3 | Sensor de proximidad: caja bajo la tolva |
| %I0.4 | Sensor de nivel: caja llena |
| %Q0.0 | Motor de la cinta transportadora |
| %Q0.1 | Válvula de llenado |
| %Q0.2 | Luz de marcha · %Q0.3 Luz de llenado · %Q0.4 Luz de llena |

## Requisitos

1. Marcha y Paro controlan el sistema en cualquier momento; la luz de marcha indica que está en funcionamiento.
2. Cada caja se detiene bajo la tolva, se llena y avanza sola.
3. La luz de llenado está encendida mientras se llena; la luz de llena desde que la caja está completa hasta que sale del sensor.
4. No se puede derramar producto.
5. Paro apaga el motor, la válvula y la luz de marcha.

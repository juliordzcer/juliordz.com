---
title: Modos de operación con selector
simulation: silo
level: 3
---
# 9. Modos de operación con selector

**Objetivo:** un solo proceso, tres modos elegidos con el selector A/B/C (%I0.5, %I0.6, %I0.7).

## Requisitos

1. **A — continuo:** como en el ejercicio 8.
2. **B — rearme manual:** la caja llena se queda bajo la tolva hasta que el operador pulsa Marcha
   una vez (un toque, no mantenido); luego avanza y la siguiente caja se detiene.
3. **C — sin llenado:** la cinta transportadora funciona de forma continua y las cajas pasan vacías.
4. En los tres modos Marcha/Paro y la luz de marcha funcionan igual, y nunca se derrama producto.

## Pistas

- En el modo B debes recordar el toque de Marcha hasta que la caja salga del sensor (`OTL`/`OTU` sobre un tag BOOL).

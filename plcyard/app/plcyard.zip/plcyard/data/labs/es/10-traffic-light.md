---
title: Semáforo de dos vías sin choques
simulation: traffic
level: 3
---
# 10. Semáforo de dos vías sin choques

**Objetivo:** secuenciar dos semáforos con temporizadores en cascada y un intervalo de todo en rojo.

## Entradas y salidas (simulación Semáforos)

| Dirección | Uso |
| --- | --- |
| %Q0.0, %Q0.1, %Q0.2 | sentido A: rojo, ámbar, verde |
| %Q0.4, %Q0.5, %Q0.6 | sentido B: rojo, ámbar, verde |

## Requisitos

1. A: verde 6 s, ámbar 2 s; luego rojo mientras B cumple su ciclo.
2. B: verde 6 s, ámbar 2 s; luego rojo mientras A cumple su ciclo.
3. Entre el ámbar de un sentido y el verde del otro hay **1 s con ambos en rojo**.
4. En todo momento cada sentido tiene exactamente una luz encendida.
5. Los autos cruzan sin chocar (déjalo correr al menos 2 minutos).

## Piénsalo

Quita el segundo de todo en rojo y observa: ¿por qué a veces chocan los autos?

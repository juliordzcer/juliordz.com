---
title: Nivel de tanque con control todo/nada
simulation: tank
level: 3
symbols:
- %I0.1 Paro (NC)
---
# 11. Nivel de tanque con control todo/nada

**Objetivo:** mantener un tanque entre dos niveles con una bomba, usando la señal analógica de nivel. Así
funciona un termostato: encendido por debajo de un valor, apagado por encima de otro.

## Entradas y salidas (simulación Tanque)

| Dirección | Dispositivo |
| --- | --- |
| %I0.0 | Marcha (pulsador NO) |
| %I0.1 | Paro (pulsador NC) |
| %I0.2 | Flotador de nivel alto (nivel ≥ 90 %) |
| %IW64 | Nivel, analógico: 0-27648 = 0-100 % |
| %Q0.0 | Bomba |
| %Q0.1 | Luz de marcha |
| %Q0.2 | Luz de alarma de nivel alto |

## Requisitos

1. Marcha y Paro controlan el sistema; la luz de marcha indica que está en funcionamiento.
2. Mientras está en marcha, la bomba arranca cuando el nivel baja de 40 % y se detiene por encima de 60 %.
3. El nivel se mantiene entonces entre aproximadamente 35 % y 65 %, sea cual sea la apertura de la salida.
4. Paro apaga la bomba.
5. La luz de alarma de nivel alto está encendida siempre que el flotador de nivel alto esté activo, en marcha o no.

## Pistas

- El 40 % de 27648 es 11059; el 60 % es 16589.
- Compara con `LES` y `GRT`, y recuerda el estado de la bomba con `OTL`/`OTU` (o un enclavamiento): entre
  40 % y 60 % ninguna condición se cumple, y la bomba debe seguir haciendo lo que estaba haciendo. Esa
  banda es la *histéresis*; sin ella la bomba estaría encendiéndose y apagándose sin parar.

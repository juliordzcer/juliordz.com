---
title: Nivel de tanque con lazo PID
simulation: tank
level: 4
---
# 12. Nivel de tanque con lazo PID

**Objetivo:** mantener el nivel exactamente en la consigna moviendo una válvula proporcional, y sintonizar el PID.

## Entradas y salidas (simulación Tanque)

| Dirección | Dispositivo |
| --- | --- |
| %IW64 | Nivel, 0-27648 = 0-100 % |
| %IW66 | Perilla de consigna, 0-27648 = 0-100 % |
| %QW64 | Válvula de entrada, 0-27648 = cerrada a totalmente abierta |

## Requisitos

1. El nivel sigue la perilla de consigna: dentro de ±2 % de ella a más tardar 60 s después de un cambio.
2. Sobrepico no mayor que 5 %.
3. Cuando la salida se abre más (una perturbación), el nivel vuelve a estar dentro de ±2 % en 60 s.
4. El tanque nunca se desborda.

## Cómo hacerlo

1. Agrega tags (Ctrl+T): `LevelPID` de tipo PID, y los tags REAL `Level` y `ValveOut`.
2. De cuentas crudas a porcentaje: `DIV %IW64 276.48 Level` (27648 / 100), y la perilla en `LevelPID.SP`.
3. `PID LevelPID Level ValveOut` (PID, variable de proceso, variable de control; los operandos de consigna, tieback,
   lazo maestro y retención son opcionales), luego `MUL ValveOut 276.48 %QW64`.
4. Sintoniza: clic derecho en el bloque PID → PID Setup. En la pestaña Tuning empieza con KP 1 y KI 0
   (solo proporcional): el nivel se estabiliza por debajo de la consigna. Luego agrega acción integral (KI 0.1,
   después 0.27 por segundo) y observa la tendencia.
5. Más corto: deja que el PID escale por ti. En la pestaña Scaling pon la PV sin escalar en 0-27648, el
   rango de ingeniería en 0-100 y la CV en 0-27648; entonces `PID LevelPID %IW64 %QW64` con la perilla
   movida a `LevelPID.SP` es todo el programa.

## Piénsalo

¿Por qué un controlador solo proporcional deja un offset aquí? ¿Qué aporta el término integral?

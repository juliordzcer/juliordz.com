---
title: Nivel de tanque PID, escalado dentro del bloque
simulation: tank
level: 4
---
# 13. Nivel de tanque PID, escalado dentro del bloque

**Objetivo:** el lazo del ejercicio 12, pero el PID convierte él mismo los valores analógicos crudos.

## Entradas y salidas (simulación Tanque)

| Dirección | Dispositivo |
| --- | --- |
| %IW64 | Nivel, 0-27648 = 0-100 % |
| %IW66 | Perilla de consigna, 0-27648 = 0-100 % |
| %QW64 | Válvula de entrada, 0-27648 = cerrada a totalmente abierta |

## Requisitos

1. El nivel sigue la perilla de consigna: dentro de ±2 % de ella a más tardar 60 s después de un cambio.
2. Sobrepico no mayor que 5 %.
3. Cuando la salida se abre más (una perturbación), el nivel vuelve a estar dentro de ±2 % en 60 s.
4. El tanque nunca se desborda.

## Cómo hacerlo

1. Agrega los tags `LevelPID` (PID) y `Setpoint` (REAL).
2. PID Setup → Scaling: PV sin escalar de 0 a 27648, unidades de ingeniería de 0 a 100, CV de 0 a 27648. Tuning:
   KP 4, KI 0.27.
3. La PV es la entrada cruda y la CV la salida cruda: `PID LevelPID %IW64 %QW64 Setpoint`.
4. La perilla a porcentaje para la consigna: `SCP %IW66 0 27648 0 100 Setpoint`.

Pruébalo en los tres lenguajes: en texto estructurado `LevelPID.PID(PV := %IW64, SP := Setpoint,
CV => %QW64);`, en diagrama de bloques de función un bloque SCALE alimentando el pin SP del bloque PID. "Compare
languages" muestra la solución de referencia en cada uno.

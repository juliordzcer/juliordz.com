---
title: Dos tanques en serie
simulation: two_tanks
level: 5
---
# 14. Dos tanques en serie

**Objetivo:** mantener el nivel del tanque inferior 2 en la consigna. Solo puedes abrir la entrada del
tanque superior 1 y la válvula entre los tanques: un proceso lento con dos retardos.

## Entradas y salidas (simulación Dos tanques)

| Dirección | Dispositivo |
| --- | --- |
| %IW64 | Nivel del tanque 1, 0-27648 = 0-100 % |
| %IW66 | Nivel del tanque 2, 0-27648 = 0-100 % |
| %IW68 | Perilla de consigna, 0-27648 = 0-100 % |
| %QW64 | Válvula de entrada del tanque 1, 0-27648 = 0-100 % |
| %QW66 | Válvula de transferencia entre los tanques, 0-27648 = 0-100 % |
| %I0.2, %I0.3, %I0.4 | Flotadores de nivel alto del tanque 1, alto del tanque 2, bajo del tanque 2 |

## Requisitos

1. El tanque 2 mantiene la consigna (±3 %) en 3 minutos.
2. Vuelve a la consigna después de que la salida del tanque 2 se abra más.
3. Sigue una nueva consigna.
4. Ningún tanque se desborda.

## Pistas

- Un solo PID del tanque 2 a la válvula de entrada funciona, pero lento. Una **cascada** es mejor: el PID
  externo sobre el tanque 2 da la consigna de un PID interno sobre el tanque 1 (el operando de lazo maestro
  de la instrucción `PID`, o conecta la CV de un PID a la SP del otro en FBD).
- Pon la válvula de transferencia en una apertura fija, por ejemplo 60 % (`MOV 16589 %QW66`).
- Deja que cada PID escale los valores crudos: PID Setup → Scaling, sin escalar 0-27648.

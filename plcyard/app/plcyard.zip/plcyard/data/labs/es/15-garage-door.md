---
title: Puerta de garaje con fotocélula de seguridad
simulation: garage
level: 3
symbols:
- %I0.0 Abrir (PB)
- %I0.1 Cerrar (PB)
- %I0.2 Paro (NC, PB)
---
# 15. Puerta de garaje con fotocélula de seguridad

**Objetivo:** abrir y cerrar una puerta de forma segura: finales de carrera, un botón de paro, una fotocélula que
protege a un auto en el vano, una luz de advertencia y una luz de cortesía.

## Entradas y salidas (simulación Puerta de garaje)

| Dirección | Dispositivo |
| --- | --- |
| %I0.0 | Abrir (pulsador) |
| %I0.1 | Cerrar (pulsador) |
| %I0.2 | Paro (pulsador, **normalmente cerrado**) |
| %I0.3 | Final de carrera de abierto (puerta totalmente arriba) |
| %I0.4 | Final de carrera de cerrado (puerta totalmente abajo) |
| %I0.5 | Fotocélula: TRUE mientras el haz está libre |
| %Q0.0, %Q0.1 | Motor de subida, motor de bajada |
| %Q0.2 | Luz de advertencia |
| %Q0.3 | Luz de cortesía |

## Requisitos

1. Abrir sube la puerta y la detiene en el final de carrera de abierto; Cerrar la baja hasta el final de carrera de cerrado.
2. Paro detiene la puerta donde esté.
3. Si el haz se interrumpe mientras la puerta se cierra, la puerta vuelve a subir; Cerrar no hace nada mientras
   haya algo en el vano.
4. La luz de advertencia parpadea mientras la puerta se mueve.
5. La luz de cortesía está encendida mientras la puerta se mueve y durante unos segundos después de que se detiene.
6. El motor nunca sigue empujando contra un tope y nunca gira en ambos sentidos a la vez.

## Pistas

- Enclava cada sentido como un arrancador de motor; el sentido opuesto y el final de carrera lo rompen.
- Recuerda la "inversión" con un enclavamiento que el final de carrera de abierto borra.
- Un temporizador auto-reseteable y una comparación sobre su acumulador hacen un intermitente; un TOF mantiene encendida
  la luz de cortesía.

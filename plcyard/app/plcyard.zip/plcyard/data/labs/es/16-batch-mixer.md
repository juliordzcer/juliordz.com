---
title: Secuencia de mezcladora por lotes
simulation: mixer
level: 5
symbols:
- %I0.0 Marcha (PB)
- %I0.1 Paro (NC, PB)
---
# 16. Secuencia de mezcladora por lotes

**Objetivo:** una secuencia con pasos: llenar dos ingredientes, mezclar y calentar, drenar, repetir.

## Entradas y salidas (simulación Mezcladora por lotes)

| Dirección | Dispositivo |
| --- | --- |
| %I0.0 | Marcha (pulsador) |
| %I0.1 | Paro (pulsador, **normalmente cerrado**) |
| %I0.2, %I0.3, %I0.4 | Flotadores de nivel bajo (5 %), medio (50 %) y alto (90 %) |
| %IW64 | Temperatura, 0-27648 = 0-100 °C |
| %Q0.0, %Q0.1 | Válvula A, válvula B |
| %Q0.2 | Motor de la mezcladora |
| %Q0.3 | Calentador |
| %Q0.4 | Válvula de drenaje |
| %Q0.5 | Luz de lote terminado |

## Requisitos

1. Marcha hace lotes uno tras otro: al menos 2 en 2 minutos.
2. Cada lote sale bien: A hasta el flotador medio, B hasta el flotador alto, mezclado al menos 5 s,
   drenado a 50-60 °C.
3. La luz de lote terminado se enciende después de cada lote.
4. Sin desbordamiento, sin calentar sin líquido, sin mezclar un tanque vacío.
5. Paro apaga todas las salidas, y nada vuelve a arrancar hasta Marcha.

## Pistas

- Guarda el paso en un tag entero (0 reposo, 1 llenar A, 2 llenar B, 3 mezclar y calentar, 4 drenar…). Cada
  salida es "paso = n"; cada transición pasa al paso siguiente cuando su condición se cumple.
- Drena hasta que el tanque esté vacío (el flotador bajo se apaga, y luego un poco más).
- Calienta con histéresis, por ejemplo encendido por debajo de 54 °C y apagado por encima de 56 °C.

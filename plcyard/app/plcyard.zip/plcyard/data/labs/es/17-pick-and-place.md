---
title: Ciclo de pick and place
simulation: pick_place
level: 4
symbols:
- %I0.0 Marcha (PB)
- %I0.1 Paro (NC, PB)
---
# 17. Ciclo de pick and place

**Objetivo:** un brazo neumático de dos ejes con pinza de vacío traslada piezas desde la entrada a una bandeja, un
ciclo tras otro, en un orden de movimientos seguro.

## Entradas y salidas (simulación Pick and place)

| Dirección | Dispositivo |
| --- | --- |
| %I0.0 | Marcha (pulsador) |
| %I0.1 | Paro (pulsador, **normalmente cerrado**) |
| %I0.2, %I0.3 | Brazo en el lado de recogida, brazo en el lado de depósito (cilindro horizontal) |
| %I0.4, %I0.5 | Brazo arriba, brazo abajo (cilindro vertical) |
| %I0.6 | Pieza esperando en el punto de recogida |
| %I0.7 | Vacío OK: la pinza sujeta una pieza |
| %Q0.0 | Cilindro horizontal: extender hacia el lado de depósito |
| %Q0.1 | Cilindro vertical: bajar |
| %Q0.2 | Vacío |
| %Q0.3 | Lámpara de ciclo |

Cada cilindro tarda un segundo de extremo a extremo. Una nueva pieza llega un segundo después de que se recogió
la anterior.

## Requisitos

1. Marcha ejecuta ciclos mientras llegan piezas: bajar, sujetar, subir, cruzar, bajar, soltar, subir, volver. Al menos
   5 piezas colocadas en un minuto.
2. Ninguna pieza se cae fuera de la bandeja.
3. El brazo nunca se mueve de lado mientras está abajo.
4. La lámpara de ciclo está encendida durante un ciclo.
5. Paro deja que el ciclo actual termine con el brazo de vuelta en casa, y no arranca ningún ciclo nuevo.

## Pistas

- Un número de paso (0 casa, 1 bajar, 2 sujetar, …) hace la secuencia fácil de seguir; cada paso espera a
  su sensor (brazo abajo, vacío OK, brazo arriba…) antes del siguiente.
- Cada salida es una lista de pasos: "bajar" está activo en los pasos donde el brazo baja o permanece abajo.
- Dale al soltado un temporizador corto (unos cientos de ms) antes de levantar el brazo.
- Solo el paso de casa mira Marcha: así Paro termina el trabajo después del ciclo actual.

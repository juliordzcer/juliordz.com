---
title: Línea de llenado y tapado de botellas
simulation: bottles
level: 4
symbols:
- %I0.0 Marcha (PB)
- %I0.1 Paro (NC, PB)
---
# 18. Línea de llenado y tapado de botellas

**Objetivo:** una cinta transportadora lleva botellas bajo una llenadora, una tapadora y una estación de inspección; detén la
cinta en cada estación y empuja fuera las botellas malas.

## Entradas y salidas (simulación Línea de botellas)

| Dirección | Dispositivo |
| --- | --- |
| %I0.0 | Marcha (pulsador) |
| %I0.1 | Paro (pulsador, **normalmente cerrado**) |
| %I0.2 | Botella en la llenadora |
| %I0.3 | Botella llena (la botella en la llenadora está al 95 % o más) |
| %I0.4 | Botella en la tapadora |
| %I0.5 | Botella en inspección |
| %I0.6 | La botella en inspección está bien |
| %Q0.0 | Cinta transportadora |
| %Q0.1 | Válvula de llenado |
| %Q0.2 | Prensa de la tapadora |
| %Q0.3 | Empujador de rechazo |
| %Q0.4 | Lámpara de marcha |

Una botella se queda bajo una estación solo si la cinta se detiene mientras el sensor de la estación la ve. La
prensa necesita medio segundo sobre una botella para taparla. Cada quinta botella lleva un tapón malo.

## Requisitos

1. Marcha hace funcionar la línea: al menos 8 botellas buenas despachadas en 2 minutos.
2. Ninguna botella mala se despacha.
3. Las botellas malas se rechazan en inspección; las buenas no.
4. Sin derrames, sin desbordamiento, sin tapar una botella en movimiento.
5. La lámpara de marcha está encendida mientras la línea funciona.
6. Paro apaga la cinta, la llenadora, la tapadora y la lámpara de marcha.

## Pistas

- La cinta avanza salvo que una estación esté trabajando: "llenando" es una botella en la llenadora que aún no está
  llena; "tapando" es una botella en la tapadora durante los primeros 0.6 s (un TON sobre el sensor).
- Llena solo mientras la cinta está detenida.
- El empujador de rechazo es simplemente "una botella en inspección que no está bien".

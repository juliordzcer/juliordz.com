---
title: Clasificación de cajas por tamaño
simulation: sorter
level: 5
symbols:
- %I0.0 Marcha (PB)
- %I0.1 Paro (NC, PB)
---
# 19. Clasificación de cajas por tamaño

**Objetivo:** medir cada caja con dos haces de luz y empujarla a la tolva de su tamaño, más adelante
en la cinta, mientras otras cajas ya van en camino.

## Entradas y salidas (simulación Cinta clasificadora)

| Dirección | Dispositivo |
| --- | --- |
| %I0.0 | Marcha (pulsador) |
| %I0.1 | Paro (pulsador, **normalmente cerrado**) |
| %I0.2 | Caja en el punto de medición |
| %I0.3 | Haz bajo bloqueado (caja mediana o grande) |
| %I0.4 | Haz alto bloqueado (caja grande) |
| %I0.5, %I0.6, %I0.7 | Caja frente al empujador 1, 2, 3 |
| %Q0.0 | Cinta transportadora |
| %Q0.1, %Q0.2, %Q0.3 | Empujador 1 (pequeña), empujador 2 (mediana), empujador 3 (grande) |
| %Q0.4 | Lámpara de marcha |

Las cajas llegan pequeña, grande, mediana, mediana, pequeña, grande, … Una caja que llega al final de la cinta
se cae.

## Requisitos

1. Marcha hace funcionar la cinta: al menos 15 cajas clasificadas en 90 segundos.
2. Cada caja va a la tolva de su tamaño.
3. Ninguna caja se cae por el final de la cinta.
4. La lámpara de marcha está encendida mientras la cinta funciona.
5. Paro detiene la cinta y apaga la lámpara de marcha.

## Pistas

- Varias cajas están entre los haces y los empujadores a la vez, así que recuerda los tamaños en orden:
  una cola (un arreglo y un índice de escritura) para cada tramo de cinta.
- Cuando una nueva caja llega al punto de medición (flanco de subida), su tamaño es 1, o 2 si el haz bajo está
  bloqueado, o 3 si el haz alto también lo está; escríbelo en la cola del empujador 1.
- Cuando una caja llega al empujador k (flanco de subida), lee el siguiente tamaño de la cola k: empújala si es
  tamaño k, si no, escríbelo en la cola k+1.
- Las direcciones indexadas funcionan en todas partes: `Q1[W1]` en un MOV, un bloque MOVE o texto estructurado.

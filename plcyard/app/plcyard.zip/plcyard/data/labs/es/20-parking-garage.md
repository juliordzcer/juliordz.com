---
title: Barreras y contador de estacionamiento
simulation: parking
level: 3
symbols: []
---
# 20. Barreras y contador de estacionamiento

**Objetivo:** dejar entrar y salir autos con dos barreras, contarlos y mostrar los espacios libres; mantener los autos
afuera cuando el estacionamiento está lleno.

## Entradas y salidas (simulación Estacionamiento)

| Dirección | Dispositivo |
| --- | --- |
| %I0.0 | Auto esperando en la entrada |
| %I0.1 | Auto pasando la barrera de entrada (haz) |
| %I0.2 | Auto esperando en la salida |
| %I0.3 | Auto pasando la barrera de salida (haz) |
| %I0.4, %I0.5 | Barrera de entrada arriba, barrera de salida arriba |
| %Q0.0 | Subir la barrera de entrada |
| %Q0.1 | Subir la barrera de salida |
| %Q0.2 | Cartel LLENO |
| %QW4 | Visor de espacios libres (BCD) |

El estacionamiento tiene diez espacios y **hay tres autos estacionados cuando arranca**. Los autos llegan con los botones "Car
arrives" y "Car leaves" (o con Traffic).

## Requisitos

1. El visor muestra los espacios libres desde el inicio (7).
2. Un auto esperando en la entrada recibe la barrera; esta baja una vez que el auto entró.
3. Los autos que entran se cuentan en el visor.
4. Un auto que sale recibe la barrera de salida y se cuenta.
5. LLENO se enciende con diez autos adentro.
6. Con el estacionamiento lleno la barrera de entrada permanece abajo para un auto que espera.
7. Cuando un auto sale, el auto que espera entra.
8. Ninguna barrera baja sobre un auto.

## Pistas

- Guarda el número de autos en un tag entero que empieza en 3 (su valor inicial en la lista de tags).
- Enclava "subir" cuando un auto espera (en la entrada solo si hay lugar), desenclávalo en el flanco
  de bajada del haz: ese es el momento en que el auto pasó, y el momento de contarlo.
- Muestra `10 - count` con una conversión a BCD (TOD) en la palabra del visor.

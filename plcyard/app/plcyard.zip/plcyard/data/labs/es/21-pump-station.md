---
title: Estación de bombas con reparto de servicio
simulation: pumps
level: 4
symbols:
- %I0.0 Reinicio de alarma (PB)
- %I0.1 Paro (NC, PB)
---
# 21. Estación de bombas con reparto de servicio

**Objetivo:** dos bombas vacían un pozo. Se turnan para desgastarse por igual, la segunda ayuda cuando
el nivel sigue subiendo, y una bomba averiada es reemplazada por la otra.

## Entradas y salidas (simulación Estación de bombas)

| Dirección | Dispositivo |
| --- | --- |
| %I0.0 | Reinicio de alarma (pulsador) |
| %I0.1 | Paro (pulsador, **normalmente cerrado**) |
| %I0.2 | Nivel bajo (15 % o más) |
| %I0.3 | Nivel de arranque (50 % o más) |
| %I0.4 | Nivel alto (75 % o más) |
| %I0.5 | Nivel de alarma de desbordamiento (95 % o más) |
| %I0.6, %I0.7 | Falla de bomba 1, falla de bomba 2 (TRUE cuando disparó la protección de la bomba) |
| %IW64 | Nivel, 0-27648 = 0-100 % |
| %Q0.0, %Q0.1 | Bomba 1, bomba 2 |
| %Q0.2 | Lámpara de alarma |

Cada bomba extrae 3 % del pozo por segundo. El deslizador de caudal de entrada llega hasta 5 % por segundo, más
de lo que una bomba puede manejar.

## Requisitos

1. Las bombas mantienen el nivel entre bajo y alto: una bomba arranca en el nivel de arranque y se detiene en
   el nivel bajo.
2. Se turnan: cada nuevo ciclo de vaciado usa la otra bomba.
3. Ambas bombas funcionan cuando el nivel sigue subiendo hasta el nivel alto.
4. Una bomba averiada se apaga y la otra toma el relevo.
5. La lámpara de alarma se enciende por una falla de bomba o por el nivel de desbordamiento.
6. Reinicio borra la alarma solo cuando la falla ya desapareció.
7. Sin desbordamiento y sin bomba funcionando en seco.
8. Paro (mantenido) apaga ambas bombas.

## Pistas

- Recuerda qué bomba es la principal en un tag entero (1 o 2) y cámbiala al inicio de cada ciclo:
  `Lead := 3 - Lead`.
- Un ciclo empieza cuando ninguna bomba funciona y se alcanza el nivel de arranque; termina en el nivel bajo.
- En el nivel alto, haz funcionar toda bomba que no esté averiada.
- Enclava la alarma; desenclávala con Reinicio solo cuando no haya falla ni nivel de desbordamiento.

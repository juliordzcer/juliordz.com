---
title: Clima de sala con calefacción y refrigeración
simulation: hvac
level: 5
symbols:
- %I0.0 Encendido (PB)
- %I0.1 Apagado (NC, PB)
---
# 22. Clima de sala con calefacción y refrigeración

**Objetivo:** mantener una sala a la temperatura de la perilla de consigna con un calentador y un enfriador, ambos
analógicos, nunca ambos a la vez y nunca sin el ventilador.

## Entradas y salidas (simulación Clima de sala)

| Dirección | Dispositivo |
| --- | --- |
| %I0.0 | Sistema encendido (pulsador) |
| %I0.1 | Sistema apagado (pulsador, **normalmente cerrado**) |
| %I0.2 | Ventana abierta |
| %I0.3 | Caudal de aire: el ventilador está funcionando |
| %IW64 | Temperatura de la sala, 0-27648 = 0-50 °C |
| %IW66 | Perilla de consigna, 0-27648 = 0-50 °C |
| %Q0.0 | Ventilador |
| %Q0.1 | Lámpara de calefacción |
| %Q0.2 | Lámpara de refrigeración |
| %QW64 | Calentador, 0-27648 = 0-100 % |
| %QW66 | Enfriador, 0-27648 = 0-100 % |

La sala arranca a 16 °C con 8 °C afuera. Calentar o enfriar sin el ventilador sobrecalienta la serpentina
(la simulación lo ignora y lo reporta); calentar y enfriar a la vez solo desperdicia energía.

## Requisitos

1. Encendido arranca el ventilador y lleva la sala a la consigna (±0.5 °C) en 2 minutos.
2. Mantiene la temperatura (±1 °C) con la ventana abierta y 18 °C afuera.
3. Enfría cuando hace calor afuera (35 °C), dentro de ±1 °C.
4. Sigue una nueva consigna (24 °C) dentro de ±1 °C.
5. Las lámparas de calefacción y refrigeración muestran qué está trabajando.
6. Nunca calienta y enfría a la vez, y nunca sin el ventilador.
7. Apagado detiene el ventilador, el calentador y el enfriador.

## Pistas

- Un solo PID puede manejar ambos: deja que su salida vaya de -100 % (refrigeración plena) a +100 % (calefacción plena)
  con el mínimo de salida del tag del PID en -100. El calentador toma la parte positiva, el
  enfriador la parte negativa.
- Escala la sala y la consigna a °C (0-27648 → 0-50) y las salidas de vuelta (0-100 % →
  0-27648).
- Sin caudal de aire, sin calefacción ni refrigeración: fuerza la demanda a 0 cuando el ventilador no está confirmado.

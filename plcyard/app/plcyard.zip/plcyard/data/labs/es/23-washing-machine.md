---
title: Programa de lavadora
simulation: washer
level: 5
symbols:
- %I0.0 Marcha (PB)
- %I0.1 Paro (NC, PB)
---
# 23. Programa de lavadora

**Objetivo:** una secuencia temporizada con enclavamientos de seguridad: trabar la puerta, llenar, lavar girando en ambos sentidos,
drenar, centrifugar, esperar a que el tambor se detenga, destrabar.

## Entradas y salidas (simulación Lavadora)

| Dirección | Dispositivo |
| --- | --- |
| %I0.0 | Marcha (pulsador) |
| %I0.1 | Paro (pulsador, **normalmente cerrado**) |
| %I0.2 | Puerta cerrada |
| %I0.3 | Puerta trabada |
| %I0.4 | Hay agua (10 % o más) |
| %I0.5 | Agua llena (80 % o más) |
| %I0.6 | Tambor detenido |
| %Q0.0 | Traba de puerta |
| %Q0.1 | Válvula de llenado |
| %Q0.2, %Q0.3 | Giro de lavado a la izquierda, giro de lavado a la derecha |
| %Q0.4 | Centrifugado |
| %Q0.5 | Bomba de drenaje |
| %Q0.6 | Lámpara de terminado |

El tambor acelera y desacelera a 400 rpm por segundo: después de un centrifugado tarda unos segundos en
detenerse.

## Requisitos

1. Marcha con la puerta cerrada ejecuta un lavado completo en 2 minutos.
2. La ropa gira en agua al menos 10 s en cada sentido.
3. El agua se drena antes de un centrifugado de al menos 5 s.
4. La lámpara de terminado se enciende al final.
5. Marcha no hace nada con la puerta abierta.
6. Paro durante un lavado detiene el tambor y destraba la puerta una vez que el tambor se detuvo.
7. La puerta nunca se destraba mientras el tambor gira, y la máquina nunca se inunda.

## Pistas

- Un número de paso: 0 reposo, 1 trabar, 2 llenar, 3 lavar, 4 drenar, 5 centrifugar, 6 esperar el tambor, 7 terminado.
- En el paso de lavado, un temporizador de unos segundos que se reinicia solo invierte el sentido.
- Drena hasta que el interruptor "hay agua" se apague, y luego un poco más.
- Paro salta a "esperar el tambor" desde cualquier paso que haga funcionar algo.

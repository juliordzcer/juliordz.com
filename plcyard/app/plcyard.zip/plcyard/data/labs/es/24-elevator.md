---
title: Ascensor de tres pisos
simulation: elevator
level: 5
symbols: []
---
# 24. Ascensor de tres pisos

**Objetivo:** atender llamadas de hall y de cabina en tres pisos: recordar cada llamada, viajar a ella, detenerse a nivel
con el piso, abrir y cerrar la puerta de forma segura.

## Entradas y salidas (simulación Ascensor)

| Dirección | Dispositivo |
| --- | --- |
| %I0.0, %I0.1, %I0.2 | Botones de llamada de hall, pisos 1-3 |
| %I0.3, %I0.4, %I0.5 | Botones de cabina, pisos 1-3 |
| %I0.6, %I0.7, %I1.0 | Cabina en piso 1, 2, 3 |
| %I1.1 | Límite de puerta abierta |
| %I1.2 | Límite de puerta cerrada |
| %I1.3 | Borde de seguridad de puerta libre (TRUE salvo que alguien esté en el vano) |
| %I1.4 | Sobrecarrera superior OK |
| %I1.5 | Sobrecarrera inferior OK |
| %Q0.0, %Q0.1 | Motor arriba, motor abajo |
| %Q0.2, %Q0.3 | Abrir puerta, cerrar puerta |
| %Q0.4, %Q0.5, %Q0.6 | Lámparas de posición, pisos 1-3 |

La cabina arranca en el piso 1 con la puerta cerrada. Viaja un piso en 3 s; la puerta abre o
cierra en 2 s.

## Requisitos

1. Una llamada de hall trae la cabina y abre la puerta en ese piso.
2. Un botón de cabina lleva la cabina a su piso.
3. Las llamadas se recuerdan (los botones solo se presionan un momento) y todas se atienden.
4. La puerta se reabre, o queda abierta, mientras alguien está en el vano.
5. Las lámparas de posición muestran el piso en que está la cabina.
6. La cabina nunca se mueve con la puerta abierta, la puerta nunca abre entre pisos y nunca cierra
   sobre alguien.

## Pistas

- Enclava un bit de llamada por piso desde sus botones de hall y de cabina; bórralo cuando la puerta esté totalmente abierta
  en ese piso.
- Guarda el último piso que pasó la cabina en un tag entero (empieza en 1).
- "Aquí" es una llamada en el piso donde está la cabina; "arriba" y "abajo" son llamadas más arriba o más abajo.
- Pasos: 0 reposo, 1 abriendo, 2 abierta (espera), 3 subiendo, 4 bajando, 5 cerrando. Cierra solo mientras
  el vano está libre; si no lo está, abre de nuevo.

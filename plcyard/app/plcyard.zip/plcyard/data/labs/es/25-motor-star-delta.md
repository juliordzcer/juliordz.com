---
title: Motor trifásico, estrella-triángulo, adelante y atrás
simulation: motor
level: 3
symbols:
- %I0.0 Adelante (PB)
- %I0.1 Atrás (PB)
- %I0.2 Paro (NC, PB)
- %I0.3 Relevador térmico OK
- %I0.4 Motor detenido
- %Q0.0 KM1 adelante
- %Q0.1 KM2 atrás
- %Q0.2 KM3 estrella
- %Q0.3 KM4 triángulo
- %Q0.4 Lámpara de marcha
- %Q0.5 Lámpara de falla
---
# 25. Motor trifásico, estrella-triángulo, adelante y atrás

**Objetivo:** arrancar un motor trifásico en estrella y pasarlo a triángulo, en cualquier sentido,
protegido por un relevador térmico, como lo hace un arrancador real.

## Entradas y salidas (simulación Motor trifásico)

| Dirección | Dispositivo |
| --- | --- |
| %I0.0 | Adelante (botón) |
| %I0.1 | Atrás (botón) |
| %I0.2 | Paro (botón, **normalmente cerrado**) |
| %I0.3 | Relevador térmico OK (contacto **normalmente cerrado**: FALSE cuando se dispara) |
| %I0.4 | Motor detenido (sensor de velocidad cero, menos de 30 rpm) |
| %Q0.0, %Q0.1 | KM1 contactor de línea adelante, KM2 contactor de línea atrás |
| %Q0.2, %Q0.3 | KM3 estrella, KM4 triángulo |
| %Q0.4 | Lámpara de marcha |
| %Q0.5 | Lámpara de falla |

## Requisitos

1. Adelante arranca el motor en estrella (KM1 + KM3) y lo pasa a triángulo (KM1 + KM4) unos
   segundos después; Atrás hace lo mismo con KM2.
2. Nunca arranca directo en triángulo.
3. Estrella y triángulo nunca están encendidos juntos; adelante y atrás tampoco.
4. Atrás se ignora mientras el motor gira hacia adelante (y al revés): primero paro, y arrancar en
   el otro sentido solo cuando el motor ya se detuvo.
5. Paro detiene el motor.
6. Un disparo del térmico suelta todos los contactores y enciende la lámpara de falla; el motor no
   puede arrancar hasta que se restablezca el relevador.
7. La lámpara de marcha está encendida mientras el motor gira.

## Pistas

- Enclava cada contactor de línea como un arrancador; pon en serie el Paro, el contacto del térmico
  y un contacto NC del otro sentido.
- Acepta el arranque solo mientras "Motor detenido" sea TRUE.
- Un temporizador que arranca con cualquiera de los contactores de línea: estrella mientras corre,
  triángulo cuando termina, cada uno con un contacto NC del otro.

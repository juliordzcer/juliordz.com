---
title: Portes logiques avec contacts
simulation: io
level: 1
symbols:
- %I0.0 Entrée A
- %I0.1 Entrée B
- %I0.2 Entrée C
- %I0.3 Entrée D
- %I0.4 Entrée E
- %I0.5 Entrée F
- %I0.6 Entrée G
- %Q0.0 Sortie AND
- %Q0.1 Sortie OR
- %Q0.2 Sortie NOT
- %Q0.3 Sortie XOR
---
# 1. Portes logiques avec contacts

**Objectif :** construire AND, OR, NOT et XOR avec des contacts `XIC`/`XIO` en série et en parallèle.

## Entrées et sorties

| Adresse | Utilisation |
| --- | --- |
| %I0.0, %I0.1 | Entrées de la porte AND |
| %I0.2, %I0.3 | Entrées de la porte OR |
| %I0.4 | Entrée de l'inverseur |
| %I0.5, %I0.6 | Entrées de la porte XOR |
| %Q0.0 … %Q0.3 | AND, OR, NOT, XOR |

## Exigences

1. %Q0.0 s'active uniquement lorsque %I0.0 **et** %I0.1 sont fermés.
2. %Q0.1 s'active lorsque %I0.2 **ou** %I0.3 est fermé.
3. %Q0.2 s'active lorsque %I0.4 est **ouvert**.
4. %Q0.3 s'active lorsque %I0.5 et %I0.6 sont **différents**.

## Indications

- Contacts en série = AND ; branches parallèles = OR ; `XIO` = NOT.
- XOR nécessite deux branches : (A et non B) ou (non A et B).

## Comment le tester

Téléchargez, mettez le PLC en RUN et parcourez la table de vérité de chaque porte avec les interrupteurs.

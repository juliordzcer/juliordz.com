---
title: Démarrage/arrêt avec auto-maintien
simulation: io
level: 1
symbols:
- %I0.0 Démarrage (NO)
- %I0.1 Arrêt (NC)
- %Q0.0 Moteur
- %Q0.1 Voyant de marche
- %Q0.2 Voyant d'arrêt
---
# 2. Démarrage/arrêt avec auto-maintien

**Objectif :** maintenir un moteur en marche après avoir relâché le bouton de démarrage.

## Entrées et sorties

| Adresse | Dispositif | Type |
| --- | --- | --- |
| %I0.0 | Démarrage | normalement ouvert |
| %I0.1 | Arrêt | **normalement fermé** |
| %Q0.0 | Moteur | |
| %Q0.1 | Voyant de marche | |
| %Q0.2 | Voyant d'arrêt | |

## Exigences

1. Fermer puis ouvrir Démarrage laisse le moteur en marche.
2. Ouvrir Arrêt (l'appuyer) coupe le moteur, même si Démarrage est encore fermé.
3. Si le fil d'Arrêt se rompt, le moteur doit aussi s'arrêter.
4. Le voyant de marche suit le moteur ; le voyant d'arrêt est allumé tant que le moteur est à l'arrêt.

## Indications

- Arrêt est NC : non appuyé, il délivre un 1. Quelle instruction l'examine ?
- Le propre contact du moteur, en parallèle avec Démarrage, constitue l'auto-maintien.

## Réfléchissez-y

Que devient le moteur si vous passez le PLC en PGM puis de nouveau en RUN ? Pourquoi ?

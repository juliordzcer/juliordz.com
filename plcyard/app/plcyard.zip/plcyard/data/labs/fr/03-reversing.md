---
title: Moteur à inversion avec verrouillage
simulation: io
level: 2
symbols:
- %I0.0 Avant (NO)
- %I0.1 Arrière (NO)
- %I0.2 Arrêt (NC)
- %Q0.0 Contacteur avant
- %Q0.1 Contacteur arrière
---
# 3. Moteur à inversion avec verrouillage

**Objectif :** faire tourner un moteur dans deux sens sans que les deux contacteurs soient jamais enclenchés en même temps.

## Exigences

1. Avant (%I0.0) démarre et maintient %Q0.0 ; Arrière (%I0.1) démarre et maintient %Q0.1.
2. Arrêt (%I0.2, NC) arrête l'un ou l'autre.
3. %Q0.0 et %Q0.1 ne doivent **jamais** être enclenchés en même temps.
4. Pour changer de sens, il faut d'abord s'arrêter : appuyer sur Arrière pendant la marche avant ne fait rien.

## Indications

- L'échelon de chaque contacteur comprend un contact `XIO` de l'autre (verrouillage).

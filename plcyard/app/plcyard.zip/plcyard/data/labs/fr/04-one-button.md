---
title: Marche et arrêt avec un seul bouton
simulation: io
level: 2
symbols:
- %I0.0 Bouton (NO, bouton-poussoir)
- %Q0.0 Lampe
---
# 4. Marche et arrêt avec un seul bouton

**Objectif :** utiliser un one shot (`ONS`) pour que chaque appui change l'état d'une lampe.

## Exigences

1. Chaque appui sur %I0.0 change %Q0.0 (marche ↔ arrêt).
2. Maintenir le bouton enfoncé ne doit **pas** faire clignoter la lampe.

## Indications

- `ONS` génère une impulsion d'un seul cycle de scrutation lorsque son échelon passe de faux à vrai.
- Avec cette impulsion et l'état actuel de la lampe, vous pouvez construire une bascule à deux branches.

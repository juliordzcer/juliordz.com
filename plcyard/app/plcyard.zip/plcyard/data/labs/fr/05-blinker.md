---
title: Lumière clignotante avec temporisateurs
simulation: io
level: 2
symbols:
- %I0.0 Activation
- %Q0.0 Lumière clignotante
---
# 5. Lumière clignotante avec temporisateurs

**Objectif :** chaîner deux temporisateurs TON pour produire un signal périodique.

## Exigences

1. Avec %I0.0 fermé, %Q0.0 est allumé pendant 1 s et éteint pendant 1 s, en répétition.
2. Ouvrir %I0.0 éteint la lumière et redémarre le cycle.

## Indices

- Déclarez deux tags TIMER (Ctrl+T ouvre la liste des tags). Les presets sont en millisecondes : 1000 correspond à
  1 s, et T#1s fonctionne aussi.
- Le bit DN du deuxième temporisateur peut réinitialiser le premier.
- Ouvrez un temporisateur dans la liste des tags pour observer ses bits EN, TT et DN à vitesse lente.

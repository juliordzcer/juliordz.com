---
title: Compteur de lots avec afficheur
simulation: io
level: 2
symbols:
- %I0.0 Capteur de pièce (NO, bouton-poussoir)
- %I0.1 Réinitialiser le lot (NO, bouton-poussoir)
- %Q0.0 Lot terminé
---
# 6. Compteur de lots avec afficheur

**Objectif :** compter les pièces avec CTU, signaler un lot terminé et afficher le comptage sur l'afficheur BCD.

## Exigences

1. Chaque impulsion sur %I0.0 compte une pièce (une impulsion = une pièce, quelle que soit sa durée).
2. À 5 pièces, %Q0.0 (lot terminé) s'allume.
3. %I0.1 réinitialise le comptage et éteint %Q0.0.
4. L'afficheur %QW4 montre toujours le nombre de pièces.

## Indices

- L'afficheur attend du BCD : convertissez l'accumulateur avec `TOD`.

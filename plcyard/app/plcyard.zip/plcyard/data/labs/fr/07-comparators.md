---
title: Tri par plage avec comparateurs
simulation: io
level: 2
symbols:
- %Q0.0 Bas
- %Q0.1 Normal
- %Q0.2 Haut
---
# 7. Tri par plage avec comparateurs

**Objectif :** lire un nombre depuis les roues codeuses (%IW4, BCD) et le classer.

## Exigences

1. Convertissez la valeur de %IW4 en binaire dans un tag INT (par exemple `Value`).
2. %Q0.0 (Bas) lorsque la valeur est inférieure à 100.
3. %Q0.1 (Normal) lorsqu'elle est comprise entre 100 et 500, inclus.
4. %Q0.2 (Haut) lorsqu'elle est supérieure à 500.
5. Une seule des trois sorties peut être allumée.

## Indices

- `FRD` convertit du BCD vers le binaire.
- `LIM` gère « entre » en une seule instruction.

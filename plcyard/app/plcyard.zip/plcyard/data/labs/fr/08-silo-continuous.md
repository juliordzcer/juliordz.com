---
title: Remplissage continu sur la ligne du silo
simulation: silo
level: 2
---
# 8. Remplissage continu sur la ligne du silo

**Objectif :** piloter un processus réel : convoyeur, capteur de position, vanne et capteur de niveau.

## Entrées et sorties (simulation Silo)

| Adresse | Dispositif |
| --- | --- |
| %I0.0 | Marche (bouton-poussoir NO) |
| %I0.1 | Arrêt (bouton-poussoir NC) |
| %I0.3 | Capteur de proximité : caisse sous la trémie |
| %I0.4 | Capteur de niveau : caisse pleine |
| %Q0.0 | Moteur du convoyeur |
| %Q0.1 | Vanne de remplissage |
| %Q0.2 | Voyant marche · %Q0.3 Voyant remplissage · %Q0.4 Voyant plein |

## Exigences

1. Marche et Arrêt commandent le système à tout moment ; le voyant marche indique qu'il tourne.
2. Chaque caisse s'arrête sous la trémie, se remplit et repart d'elle-même.
3. Le voyant remplissage est allumé pendant le remplissage ; le voyant plein dès que la caisse est pleine jusqu'à ce qu'elle quitte le capteur.
4. Aucun produit ne doit être renversé.
5. Arrêt coupe le moteur, la vanne et le voyant marche.

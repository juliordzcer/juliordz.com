---
title: Modes de fonctionnement avec un sélecteur
simulation: silo
level: 3
---
# 9. Modes de fonctionnement avec un sélecteur

**Objectif :** un seul processus, trois modes choisis avec le sélecteur A/B/C (%I0.5, %I0.6, %I0.7).

## Exigences

1. **A — continu :** comme dans l'exercice 8.
2. **B — redémarrage manuel :** la caisse pleine reste sous la trémie jusqu'à ce que l'opérateur appuie une fois sur Marche
   (une impulsion, pas un maintien) ; ensuite elle repart et la caisse suivante s'arrête.
3. **C — sans remplissage :** le convoyeur tourne en continu et les caisses passent vides.
4. Dans les trois modes, Marche/Arrêt et le voyant marche fonctionnent de la même façon, et aucun produit n'est jamais renversé.

## Indices

- En mode B, vous devez mémoriser l'impulsion de Marche jusqu'à ce que la caisse quitte le capteur (`OTL`/`OTU` sur un tag BOOL).

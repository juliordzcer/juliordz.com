---
title: Feux tricolores à deux sens sans collision
simulation: traffic
level: 3
---
# 10. Feux tricolores à deux sens sans collision

**Objectif :** séquencer deux feux tricolores avec des temporisateurs en cascade et un intervalle tout rouge.

## Entrées et sorties (simulation Feux tricolores)

| Adresse | Usage |
| --- | --- |
| %Q0.0, %Q0.1, %Q0.2 | sens A : rouge, orange, vert |
| %Q0.4, %Q0.5, %Q0.6 | sens B : rouge, orange, vert |

## Exigences

1. A : vert 6 s, orange 2 s ; puis rouge pendant que B exécute son cycle.
2. B : vert 6 s, orange 2 s ; puis rouge pendant que A exécute son cycle.
3. Entre l'orange d'un sens et le vert de l'autre, il y a **1 s avec les deux au rouge**.
4. À tout moment, chaque sens a exactement un feu allumé.
5. Les voitures se croisent sans collision (faites tourner au moins 2 minutes).

## Réfléchissez-y

Supprimez la seconde de tout rouge et observez : pourquoi les voitures se percutent-elles parfois ?

---
title: Niveau de cuve avec régulation tout ou rien
simulation: tank
level: 3
symbols:
- %I0.1 Arrêt (NC)
---
# 11. Niveau de cuve avec régulation tout ou rien

**Objectif :** maintenir une cuve entre deux niveaux avec une pompe, en utilisant le signal analogique de niveau. C'est ainsi que fonctionne un
thermostat : marche en dessous d'une valeur, arrêt au-dessus d'une autre.

## Entrées et sorties (simulation Cuve)

| Adresse | Dispositif |
| --- | --- |
| %I0.0 | Marche (bouton-poussoir NO) |
| %I0.1 | Arrêt (bouton-poussoir NC) |
| %I0.2 | Flotteur de niveau haut (niveau ≥ 90 %) |
| %IW64 | Niveau, analogique : 0-27648 = 0-100 % |
| %Q0.0 | Pompe |
| %Q0.1 | Voyant marche |
| %Q0.2 | Voyant d'alarme niveau haut |

## Exigences

1. Marche et Arrêt commandent le système ; le voyant marche indique qu'il tourne.
2. En marche, la pompe démarre lorsque le niveau descend sous 40 % et s'arrête au-dessus de 60 %.
3. Le niveau reste alors entre environ 35 % et 65 %, quelle que soit l'ouverture de la sortie.
4. Arrêt coupe la pompe.
5. Le voyant d'alarme niveau haut est allumé chaque fois que le flotteur de niveau haut est actif, en marche ou non.

## Indices

- 40 % de 27648 vaut 11059 ; 60 % vaut 16589.
- Comparez avec `LES` et `GRT`, et mémorisez l'état de la pompe avec `OTL`/`OTU` (ou un auto-maintien) : entre
  40 % et 60 %, aucune des deux conditions n'est vraie, et la pompe doit continuer ce qu'elle faisait. Cet
  écart est l'*hystérésis* ; sans lui, la pompe s'enclencherait et se couperait sans arrêt.

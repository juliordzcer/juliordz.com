---
title: Niveau de cuve avec une boucle PID
simulation: tank
level: 4
---
# 12. Niveau de cuve avec une boucle PID

**Objectif :** maintenir le niveau exactement à la consigne en actionnant une vanne proportionnelle, et régler le PID.

## Entrées et sorties (simulation Cuve)

| Adresse | Dispositif |
| --- | --- |
| %IW64 | Niveau, 0-27648 = 0-100 % |
| %IW66 | Bouton de consigne, 0-27648 = 0-100 % |
| %QW64 | Vanne d'entrée, 0-27648 = fermée à pleine ouverture |

## Exigences

1. Le niveau suit le bouton de consigne : à ±2 % de celui-ci au plus tard 60 s après un changement.
2. Dépassement de 5 % maximum.
3. Lorsque la sortie s'ouvre davantage (une perturbation), le niveau revient à ±2 % en 60 s.
4. La cuve ne déborde jamais.

## Comment faire

1. Ajoutez des tags (Ctrl+T) : `LevelPID` de type PID, et les tags REAL `Level` et `ValveOut`.
2. Des valeurs brutes au pourcentage : `DIV %IW64 276.48 Level` (27648 / 100), et le bouton dans `LevelPID.SP`.
3. `PID LevelPID Level ValveOut` (PID, variable de procédé, variable de commande ; les opérandes consigne, tieback,
   boucle maître et inhold sont facultatifs), puis `MUL ValveOut 276.48 %QW64`.
4. Réglez : clic droit sur le bloc PID → PID Setup. Dans l'onglet Tuning, commencez par KP 1 et KI 0
   (proportionnel seul) : le niveau se stabilise sous la consigne. Ajoutez ensuite l'action intégrale (KI 0.1,
   puis 0.27 par seconde) et observez la courbe.
5. Plus court : laissez le PID faire la mise à l'échelle. Dans l'onglet Scaling, réglez la PV non mise à l'échelle sur 0-27648, la
   plage d'ingénierie sur 0-100 et la CV sur 0-27648 ; puis `PID LevelPID %IW64 %QW64` avec le bouton
   déplacé dans `LevelPID.SP` constitue tout le programme.

## Réfléchissez-y

Pourquoi un régulateur purement proportionnel laisse-t-il un écart ici ? Qu'apporte le terme intégral ?

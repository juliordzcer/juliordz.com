---
title: Niveau de cuve PID, mise à l'échelle dans le bloc
simulation: tank
level: 4
---
# 13. Niveau de cuve PID, mise à l'échelle dans le bloc

**Objectif :** la boucle de l'exercice 12, mais le PID convertit lui-même les valeurs analogiques brutes.

## Entrées et sorties (simulation Cuve)

| Adresse | Dispositif |
| --- | --- |
| %IW64 | Niveau, 0-27648 = 0-100 % |
| %IW66 | Bouton de consigne, 0-27648 = 0-100 % |
| %QW64 | Vanne d'entrée, 0-27648 = fermée à pleine ouverture |

## Exigences

1. Le niveau suit le bouton de consigne : à ±2 % de celui-ci au plus tard 60 s après un changement.
2. Dépassement de 5 % maximum.
3. Lorsque la sortie s'ouvre davantage (une perturbation), le niveau revient à ±2 % en 60 s.
4. La cuve ne déborde jamais.

## Comment faire

1. Ajoutez les tags `LevelPID` (PID) et `Setpoint` (REAL).
2. PID Setup → Scaling : PV non mise à l'échelle 0 à 27648, unités d'ingénierie 0 à 100, CV 0 à 27648. Tuning :
   KP 4, KI 0.27.
3. La PV est l'entrée brute et la CV la sortie brute : `PID LevelPID %IW64 %QW64 Setpoint`.
4. Le bouton en pourcentage pour la consigne : `SCP %IW66 0 27648 0 100 Setpoint`.

Essayez-le dans les trois langages : en texte structuré `LevelPID.PID(PV := %IW64, SP := Setpoint,
CV => %QW64);`, en schéma de blocs fonctionnels un bloc SCALE alimentant la broche SP du bloc PID. « Compare
languages » montre la solution de référence dans chacun.

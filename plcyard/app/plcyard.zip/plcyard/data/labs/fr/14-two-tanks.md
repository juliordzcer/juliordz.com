---
title: Deux cuves en série
simulation: two_tanks
level: 5
---
# 14. Deux cuves en série

**Objectif :** maintenir le niveau de la cuve inférieure 2 à la consigne. Vous ne pouvez ouvrir que l'entrée de la
cuve supérieure 1 et la vanne entre les cuves : un processus lent avec deux retards.

## Entrées et sorties (simulation Deux cuves)

| Adresse | Dispositif |
| --- | --- |
| %IW64 | Niveau cuve 1, 0-27648 = 0-100 % |
| %IW66 | Niveau cuve 2, 0-27648 = 0-100 % |
| %IW68 | Bouton de consigne, 0-27648 = 0-100 % |
| %QW64 | Vanne d'entrée de la cuve 1, 0-27648 = 0-100 % |
| %QW66 | Vanne de transfert entre les cuves, 0-27648 = 0-100 % |
| %I0.2, %I0.3, %I0.4 | Flotteurs niveau haut cuve 1, niveau haut cuve 2, niveau bas cuve 2 |

## Exigences

1. La cuve 2 maintient la consigne (±3 %) en 3 minutes.
2. Elle revient à la consigne après que la sortie de la cuve 2 s'ouvre davantage.
3. Elle suit une nouvelle consigne.
4. Aucune cuve ne déborde.

## Indices

- Un seul PID de la cuve 2 vers la vanne d'entrée fonctionne, mais lentement. Une **cascade** est préférable : le PID
  externe sur la cuve 2 donne la consigne d'un PID interne sur la cuve 1 (l'opérande boucle maître
  de l'instruction `PID`, ou reliez la CV d'un PID au SP de l'autre en FBD).
- Réglez la vanne de transfert sur une ouverture fixe, par exemple 60 % (`MOV 16589 %QW66`).
- Laissez chaque PID mettre à l'échelle les valeurs brutes : PID Setup → Scaling, non mise à l'échelle 0-27648.

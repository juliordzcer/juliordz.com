---
title: Porte de garage avec cellule de sécurité
simulation: garage
level: 3
symbols:
- %I0.0 Ouvrir (PB)
- %I0.1 Fermer (PB)
- %I0.2 Arrêt (NC, PB)
---
# 15. Porte de garage avec cellule de sécurité

**Objectif :** ouvrir et fermer une porte en toute sécurité : fins de course, bouton d'arrêt, une cellule qui
protège une voiture dans l'embrasure, un voyant d'avertissement et un éclairage de courtoisie.

## Entrées et sorties (simulation Porte de garage)

| Adresse | Dispositif |
| --- | --- |
| %I0.0 | Ouvrir (bouton-poussoir) |
| %I0.1 | Fermer (bouton-poussoir) |
| %I0.2 | Arrêt (bouton-poussoir, **normalement fermé**) |
| %I0.3 | Fin de course ouverture (porte complètement haute) |
| %I0.4 | Fin de course fermeture (porte complètement basse) |
| %I0.5 | Cellule : TRUE tant que le faisceau est libre |
| %Q0.0, %Q0.1 | Moteur montée, moteur descente |
| %Q0.2 | Voyant d'avertissement |
| %Q0.3 | Éclairage de courtoisie |

## Exigences

1. Ouvrir fait monter la porte et l'arrête au fin de course d'ouverture ; Fermer la fait descendre jusqu'au fin de course de fermeture.
2. Arrêt immobilise la porte là où elle est.
3. Si le faisceau est coupé pendant la fermeture, la porte remonte ; Fermer ne fait rien tant que
   quelque chose se trouve dans l'embrasure.
4. Le voyant d'avertissement clignote pendant que la porte bouge.
5. L'éclairage de courtoisie est allumé pendant que la porte bouge et pendant quelques secondes après son arrêt.
6. Le moteur ne force jamais contre un fin de course et ne tourne jamais dans les deux sens à la fois.

## Indices

- Auto-maintien dans chaque sens comme un démarreur moteur ; le sens opposé et le fin de course le coupent.
- Mémorisez l'« inversion » avec un verrou que le fin de course d'ouverture efface.
- Un temporisateur à auto-réinitialisation et une comparaison sur son accumulateur font un clignotant ; un TOF maintient l'éclairage
  de courtoisie allumé.

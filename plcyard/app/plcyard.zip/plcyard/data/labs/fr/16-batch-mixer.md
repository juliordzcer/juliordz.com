---
title: Séquence de malaxeur par lots
simulation: mixer
level: 5
symbols:
- %I0.0 Marche (PB)
- %I0.1 Arrêt (NC, PB)
---
# 16. Séquence de malaxeur par lots

**Objectif :** une séquence par étapes : remplir deux ingrédients, malaxer et chauffer, vidanger, recommencer.

## Entrées et sorties (simulation Malaxeur par lots)

| Adresse | Dispositif |
| --- | --- |
| %I0.0 | Marche (bouton-poussoir) |
| %I0.1 | Arrêt (bouton-poussoir, **normalement fermé**) |
| %I0.2, %I0.3, %I0.4 | Flotteurs niveau bas (5 %), milieu (50 %) et haut (90 %) |
| %IW64 | Température, 0-27648 = 0-100 °C |
| %Q0.0, %Q0.1 | Vanne A, vanne B |
| %Q0.2 | Moteur du malaxeur |
| %Q0.3 | Résistance chauffante |
| %Q0.4 | Vanne de vidange |
| %Q0.5 | Voyant lot terminé |

## Exigences

1. Marche enchaîne les lots les uns après les autres : au moins 2 en 2 minutes.
2. Chaque lot est bon : A jusqu'au flotteur du milieu, B jusqu'au flotteur haut, malaxé au moins 5 s,
   vidangé à 50-60 °C.
3. Le voyant lot terminé s'allume après chaque lot.
4. Pas de débordement, pas de chauffe sans liquide, pas de malaxage d'une cuve vide.
5. Arrêt coupe toutes les sorties, et rien ne redémarre avant Marche.

## Indices

- Mémorisez l'étape dans un tag entier (0 repos, 1 remplissage A, 2 remplissage B, 3 malaxage et chauffe, 4 vidange…). Chaque
  sortie vaut « étape = n » ; chaque transition passe à l'étape suivante lorsque sa condition est vraie.
- Vidangez jusqu'à ce que la cuve soit vide (le flotteur bas retombe, puis un peu plus longtemps).
- Chauffez avec hystérésis, par exemple marche sous 54 °C et arrêt au-dessus de 56 °C.

---
title: Cycle de prise et dépose
simulation: pick_place
level: 4
symbols:
- %I0.0 Départ (PB)
- %I0.1 Arrêt (NC, PB)
---
# 17. Cycle de prise et dépose

**Objectif :** un bras pneumatique à deux axes avec une pince à vide déplace des pièces de l'entrée vers un plateau, un
cycle après l'autre, dans un ordre de mouvements sûr.

## Entrées et sorties (simulation Prise et dépose)

| Adresse | Dispositif |
| --- | --- |
| %I0.0 | Départ (bouton-poussoir) |
| %I0.1 | Arrêt (bouton-poussoir, **normalement fermé**) |
| %I0.2, %I0.3 | Bras côté prise, bras côté dépose (vérin horizontal) |
| %I0.4, %I0.5 | Bras en haut, bras en bas (vérin vertical) |
| %I0.6 | Pièce en attente au point de prise |
| %I0.7 | Vide OK : la pince tient une pièce |
| %Q0.0 | Vérin horizontal : sortir vers le côté dépose |
| %Q0.1 | Vérin vertical : descendre |
| %Q0.2 | Vide |
| %Q0.3 | Voyant de cycle |

Chaque vérin met une seconde d'un bout à l'autre. Une nouvelle pièce arrive une seconde après que la dernière
a été prise.

## Exigences

1. Départ enchaîne les cycles tant que des pièces arrivent : descendre, saisir, monter, traverser, descendre, relâcher, monter, revenir. Au moins
   5 pièces déposées en une minute.
2. Aucune pièce n'est lâchée en dehors du plateau.
3. Le bras ne se déplace jamais latéralement tant qu'il est en bas.
4. Le voyant de cycle est allumé pendant un cycle.
5. Arrêt laisse le cycle en cours se terminer avec le bras revenu à la position initiale, et aucun nouveau cycle ne démarre.

## Indices

- Un numéro d'étape (0 initiale, 1 descendre, 2 saisir, …) rend la séquence facile à suivre ; chaque étape attend
  son capteur (bras en bas, vide OK, bras en haut…) avant la suivante.
- Chaque sortie est une liste d'étapes : « descendre » est actif dans les étapes où le bras descend ou reste en bas.
- Donnez au relâchement un court temporisateur (quelques centaines de ms) avant de lever le bras.
- Seule l'étape initiale regarde Run : Arrêt termine alors le travail après le cycle en cours.

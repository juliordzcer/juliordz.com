---
title: Ligne de remplissage et de bouchage de bouteilles
simulation: bottles
level: 4
symbols:
- %I0.0 Démarrage (PB)
- %I0.1 Arrêt (NC, PB)
---
# 18. Ligne de remplissage et de bouchage de bouteilles

**Objectif :** un convoyeur transporte des bouteilles sous une remplisseuse, une boucheuse et un poste d'inspection ; arrêter la
bande à chaque poste, et pousser les mauvaises bouteilles hors de la ligne.

## Entrées et sorties (simulation Ligne de bouteilles)

| Adresse | Dispositif |
| --- | --- |
| %I0.0 | Démarrage (bouton-poussoir) |
| %I0.1 | Arrêt (bouton-poussoir, **normalement fermé**) |
| %I0.2 | Bouteille à la remplisseuse |
| %I0.3 | Bouteille pleine (la bouteille à la remplisseuse est à 95 % ou plus) |
| %I0.4 | Bouteille à la boucheuse |
| %I0.5 | Bouteille à l'inspection |
| %I0.6 | La bouteille à l'inspection est bonne |
| %Q0.0 | Convoyeur |
| %Q0.1 | Vanne de remplissage |
| %Q0.2 | Presse de la boucheuse |
| %Q0.3 | Poussoir de rejet |
| %Q0.4 | Voyant de marche |

Une bouteille ne reste sous un poste que si le convoyeur s'arrête pendant que le capteur du poste la voit. La
presse a besoin d'une demi-seconde sur une bouteille pour la boucher. Une bouteille sur cinq reçoit un mauvais bouchon.

## Exigences

1. Démarrage fait tourner la ligne : au moins 8 bonnes bouteilles expédiées en 2 minutes.
2. Aucune mauvaise bouteille n'est expédiée.
3. Les mauvaises bouteilles sont rejetées à l'inspection ; les bonnes ne le sont pas.
4. Pas de débordement, pas de trop-plein, pas de bouchage d'une bouteille en mouvement.
5. Le voyant de marche est allumé pendant que la ligne tourne.
6. Arrêt coupe le convoyeur, la remplisseuse, la boucheuse et le voyant de marche.

## Indications

- Le convoyeur tourne sauf si un poste travaille : « remplissage » est une bouteille à la remplisseuse qui n'est pas
  encore pleine ; « bouchage » est une bouteille à la boucheuse pendant les 0,6 premières s (un TON sur le capteur).
- Remplir uniquement pendant que le convoyeur est arrêté.
- Le poussoir de rejet est simplement « une bouteille à l'inspection qui n'est pas bonne ».

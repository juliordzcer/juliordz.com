---
title: Tri de caisses par taille
simulation: sorter
level: 5
symbols:
- %I0.0 Démarrage (PB)
- %I0.1 Arrêt (NC, PB)
---
# 19. Tri de caisses par taille

**Objectif :** mesurer chaque caisse avec deux faisceaux lumineux et la pousser dans le bac correspondant à sa taille, plus loin
sur la bande, alors que d'autres caisses sont déjà en route.

## Entrées et sorties (simulation Convoyeur de tri)

| Adresse | Dispositif |
| --- | --- |
| %I0.0 | Démarrage (bouton-poussoir) |
| %I0.1 | Arrêt (bouton-poussoir, **normalement fermé**) |
| %I0.2 | Caisse au point de mesure |
| %I0.3 | Faisceau bas coupé (caisse moyenne ou grande) |
| %I0.4 | Faisceau haut coupé (grande caisse) |
| %I0.5, %I0.6, %I0.7 | Caisse devant le poussoir 1, 2, 3 |
| %Q0.0 | Convoyeur |
| %Q0.1, %Q0.2, %Q0.3 | Poussoir 1 (petite), poussoir 2 (moyenne), poussoir 3 (grande) |
| %Q0.4 | Voyant de marche |

Les caisses arrivent petite, grande, moyenne, moyenne, petite, grande, … Une caisse qui atteint l'extrémité de la bande
tombe.

## Exigences

1. Démarrage fait tourner la bande : au moins 15 caisses triées en 90 secondes.
2. Chaque caisse va dans le bac correspondant à sa taille.
3. Aucune caisse ne tombe à l'extrémité de la bande.
4. Le voyant de marche est allumé pendant que la bande tourne.
5. Arrêt arrête la bande et éteint le voyant de marche.

## Indications

- Plusieurs caisses se trouvent à la fois entre les faisceaux et les poussoirs, il faut donc mémoriser les tailles dans l'ordre :
  une file (un tableau et un index d'écriture) pour chaque tronçon de bande.
- Quand une nouvelle caisse atteint le point de mesure (front montant), sa taille vaut 1, ou 2 si le faisceau bas est
  coupé, ou 3 si le faisceau haut est coupé aussi ; l'écrire dans la file du poussoir 1.
- Quand une caisse atteint le poussoir k (front montant), lire la taille suivante dans la file k : la pousser si c'est la
  taille k, sinon l'écrire dans la file k+1.
- Les adresses indexées fonctionnent partout : `Q1[W1]` dans un MOV, un bloc MOVE ou en texte structuré.

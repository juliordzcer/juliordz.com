---
title: Barrières et compteur de parking
simulation: parking
level: 3
symbols: []
---
# 20. Barrières et compteur de parking

**Objectif :** laisser entrer et sortir les voitures avec deux barrières, les compter et afficher les places libres ; garder les voitures
dehors quand le parking est plein.

## Entrées et sorties (simulation Parking)

| Adresse | Dispositif |
| --- | --- |
| %I0.0 | Voiture en attente à l'entrée |
| %I0.1 | Voiture franchissant la barrière d'entrée (faisceau) |
| %I0.2 | Voiture en attente à la sortie |
| %I0.3 | Voiture franchissant la barrière de sortie (faisceau) |
| %I0.4, %I0.5 | Barrière d'entrée levée, barrière de sortie levée |
| %Q0.0 | Lever la barrière d'entrée |
| %Q0.1 | Lever la barrière de sortie |
| %Q0.2 | Panneau COMPLET |
| %QW4 | Affichage des places libres (BCD) |

Le parking compte dix places et **trois voitures sont garées au démarrage**. Les voitures arrivent avec les boutons « Voiture
arrive » et « Voiture part » (ou avec Trafic).

## Exigences

1. L'affichage indique les places libres dès le départ (7).
2. Une voiture en attente à l'entrée obtient la barrière ; elle se baisse une fois la voiture entrée.
3. Les voitures qui entrent sont comptées sur l'affichage.
4. Une voiture qui sort obtient la barrière de sortie et est comptée.
5. COMPLET s'allume avec dix voitures à l'intérieur.
6. Quand le parking est plein, la barrière d'entrée reste baissée pour une voiture en attente.
7. Quand une voiture sort, la voiture en attente entre.
8. Aucune barrière ne se baisse sur une voiture.

## Indications

- Gardez le nombre de voitures dans une variable entière qui démarre à 3 (sa valeur initiale dans la liste des variables).
- Verrouillez « lever » quand une voiture attend (à l'entrée seulement s'il y a de la place), déverrouillez-le sur le front
  descendant du faisceau : c'est le moment où la voiture est passée, et le moment de la compter.
- Affichez `10 - count` avec une conversion BCD (TOD) sur le mot d'affichage.

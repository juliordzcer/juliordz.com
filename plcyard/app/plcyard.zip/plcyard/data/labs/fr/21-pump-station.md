---
title: Station de pompage avec alternance
simulation: pumps
level: 4
symbols:
- %I0.0 Réarmement alarme (PB)
- %I0.1 Arrêt (NC, PB)
---
# 21. Station de pompage avec alternance

**Objectif :** deux pompes vident un puisard. Elles alternent pour s'user de façon égale, la seconde aide quand
le niveau continue de monter, et une pompe en défaut est remplacée par l'autre.

## Entrées et sorties (simulation Station de pompage)

| Adresse | Dispositif |
| --- | --- |
| %I0.0 | Réarmement alarme (bouton-poussoir) |
| %I0.1 | Arrêt (bouton-poussoir, **normalement fermé**) |
| %I0.2 | Niveau bas (15 % ou plus) |
| %I0.3 | Niveau de démarrage (50 % ou plus) |
| %I0.4 | Niveau haut (75 % ou plus) |
| %I0.5 | Niveau d'alarme de débordement (95 % ou plus) |
| %I0.6, %I0.7 | Défaut pompe 1, défaut pompe 2 (TRUE quand la protection de la pompe a déclenché) |
| %IW64 | Niveau, 0-27648 = 0-100 % |
| %Q0.0, %Q0.1 | Pompe 1, pompe 2 |
| %Q0.2 | Voyant d'alarme |

Chaque pompe évacue 3 % du puisard par seconde. Le curseur d'arrivée d'eau monte jusqu'à 5 % par seconde, plus
qu'une seule pompe ne peut évacuer.

## Exigences

1. Les pompes maintiennent le niveau entre bas et haut : une pompe démarre au niveau de démarrage et s'arrête au
   niveau bas.
2. Elles alternent : chaque nouveau cycle de vidage utilise l'autre pompe.
3. Les deux pompes tournent quand le niveau continue de monter jusqu'au niveau haut.
4. Une pompe en défaut est coupée et l'autre prend le relais.
5. Le voyant d'alarme s'allume pour un défaut de pompe ou le niveau de débordement.
6. Le réarmement efface l'alarme seulement une fois le défaut disparu.
7. Pas de débordement et pas de pompe qui tourne à sec.
8. Arrêt (maintenu) coupe les deux pompes.

## Indications

- Mémorisez quelle pompe est maître dans une variable entière (1 ou 2) et changez-la au début de chaque cycle :
  `Lead := 3 - Lead`.
- Un cycle commence quand aucune pompe ne tourne et que le niveau de démarrage est atteint ; il se termine au niveau bas.
- Au niveau haut, faites tourner toutes les pompes qui ne sont pas en défaut.
- Verrouillez l'alarme ; déverrouillez-la avec Réarmement seulement en l'absence de défaut et de niveau de débordement.

---
title: Climat de pièce avec chauffage et refroidissement
simulation: hvac
level: 5
symbols:
- %I0.0 Marche (PB)
- %I0.1 Arrêt (NC, PB)
---
# 22. Climat de pièce avec chauffage et refroidissement

**Objectif :** maintenir une pièce à la température du bouton de consigne avec un chauffage et un refroidissement, tous deux
analogiques, jamais les deux à la fois et jamais sans le ventilateur.

## Entrées et sorties (simulation Climat de pièce)

| Adresse | Dispositif |
| --- | --- |
| %I0.0 | Système en marche (bouton-poussoir) |
| %I0.1 | Système à l'arrêt (bouton-poussoir, **normalement fermé**) |
| %I0.2 | Fenêtre ouverte |
| %I0.3 | Débit d'air : le ventilateur tourne |
| %IW64 | Température de la pièce, 0-27648 = 0-50 °C |
| %IW66 | Bouton de consigne, 0-27648 = 0-50 °C |
| %Q0.0 | Ventilateur |
| %Q0.1 | Voyant de chauffage |
| %Q0.2 | Voyant de refroidissement |
| %QW64 | Chauffage, 0-27648 = 0-100 % |
| %QW66 | Refroidissement, 0-27648 = 0-100 % |

La pièce démarre à 16 °C avec 8 °C à l'extérieur. Chauffer ou refroidir sans le ventilateur surchauffe la batterie
(la simulation l'ignore et le signale) ; chauffer et refroidir en même temps ne fait que gaspiller de l'énergie.

## Exigences

1. Marche démarre le ventilateur et amène la pièce à la consigne (±0,5 °C) en 2 minutes.
2. Il maintient la température (±1 °C) avec la fenêtre ouverte et 18 °C à l'extérieur.
3. Il refroidit quand il fait chaud dehors (35 °C), à ±1 °C près.
4. Il suit une nouvelle consigne (24 °C) à ±1 °C près.
5. Les voyants de chauffage et de refroidissement montrent ce qui fonctionne.
6. Il ne chauffe et ne refroidit jamais en même temps, et jamais sans le ventilateur.
7. Arrêt coupe le ventilateur, le chauffage et le refroidissement.

## Indications

- Un seul PID peut piloter les deux : laissez sa sortie aller de -100 % (refroidissement maximal) à +100 % (chauffage maximal)
  avec le minimum de sortie de la variable PID réglé à -100. Le chauffage reçoit la partie positive, le
  refroidissement la partie négative.
- Mettez à l'échelle la pièce et la consigne en °C (0-27648 → 0-50) et les sorties en retour (0-100 % →
  0-27648).
- Pas de débit d'air, pas de chauffage ni de refroidissement : forcez la demande à 0 quand le ventilateur n'est pas confirmé.

---
title: Programme de machine à laver
simulation: washer
level: 5
symbols:
- %I0.0 Démarrage (PB)
- %I0.1 Arrêt (NC, PB)
---
# 23. Programme de machine à laver

**Objectif :** une séquence temporisée avec verrouillages de sécurité : verrouiller la porte, remplir, laver en tournant dans les deux sens,
vidanger, essorer, attendre l'arrêt du tambour, déverrouiller.

## Entrées et sorties (simulation Machine à laver)

| Adresse | Dispositif |
| --- | --- |
| %I0.0 | Démarrage (bouton-poussoir) |
| %I0.1 | Arrêt (bouton-poussoir, **normalement fermé**) |
| %I0.2 | Porte fermée |
| %I0.3 | Porte verrouillée |
| %I0.4 | Eau présente (10 % ou plus) |
| %I0.5 | Eau pleine (80 % ou plus) |
| %I0.6 | Tambour arrêté |
| %Q0.0 | Verrou de porte |
| %Q0.1 | Électrovanne de remplissage |
| %Q0.2, %Q0.3 | Lavage sens gauche, lavage sens droite |
| %Q0.4 | Essorage |
| %Q0.5 | Pompe de vidange |
| %Q0.6 | Voyant de fin |

Le tambour accélère et ralentit à 400 tr/min par seconde : après un essorage, il met quelques secondes à
s'arrêter.

## Exigences

1. Démarrage avec la porte fermée exécute un lavage complet en 2 minutes.
2. Le linge tourne dans l'eau au moins 10 s dans chaque sens.
3. L'eau est vidangée avant un essorage d'au moins 5 s.
4. Le voyant de fin s'allume à la fin.
5. Démarrage ne fait rien avec la porte ouverte.
6. Arrêt pendant un lavage arrête le tambour et déverrouille la porte une fois le tambour arrêté.
7. La porte ne se déverrouille jamais pendant que le tambour tourne, et la machine ne déborde jamais.

## Indications

- Un seul numéro d'étape : 0 repos, 1 verrouillage, 2 remplissage, 3 lavage, 4 vidange, 5 essorage, 6 attente du tambour, 7 fin.
- À l'étape de lavage, un temporisateur de quelques secondes qui se relance lui-même inverse le sens.
- Vidanger jusqu'à ce que le contact « eau présente » retombe, puis un peu plus longtemps.
- Arrêt saute à « attente du tambour » depuis toute étape qui fait fonctionner quelque chose.

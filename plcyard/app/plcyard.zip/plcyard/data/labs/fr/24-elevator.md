---
title: Ascenseur à trois étages
simulation: elevator
level: 5
symbols: []
---
# 24. Ascenseur à trois étages

**Objectif :** desservir les appels palier et cabine sur trois étages : mémoriser chaque appel, s'y rendre, s'arrêter à niveau
avec l'étage, ouvrir et fermer la porte en toute sécurité.

## Entrées et sorties (simulation Ascenseur)

| Adresse | Dispositif |
| --- | --- |
| %I0.0, %I0.1, %I0.2 | Boutons d'appel palier, étages 1-3 |
| %I0.3, %I0.4, %I0.5 | Boutons cabine, étages 1-3 |
| %I0.6, %I0.7, %I1.0 | Cabine à l'étage 1, 2, 3 |
| %I1.1 | Fin de course porte ouverte |
| %I1.2 | Fin de course porte fermée |
| %I1.3 | Barrière de sécurité de porte dégagée (TRUE sauf si quelqu'un est dans l'embrasure) |
| %I1.4 | Dépassement haut OK |
| %I1.5 | Dépassement bas OK |
| %Q0.0, %Q0.1 | Moteur montée, moteur descente |
| %Q0.2, %Q0.3 | Ouverture porte, fermeture porte |
| %Q0.4, %Q0.5, %Q0.6 | Voyants de position, étages 1-3 |

La cabine démarre à l'étage 1 avec la porte fermée. Elle parcourt un étage en 3 s ; la porte s'ouvre ou
se ferme en 2 s.

## Exigences

1. Un appel palier amène la cabine et ouvre la porte à cet étage.
2. Un bouton cabine amène la cabine à son étage.
3. Les appels sont mémorisés (les boutons ne sont pressés qu'un instant) et tous sont desservis.
4. La porte se rouvre, ou reste ouverte, tant que quelqu'un est dans l'embrasure.
5. Les voyants de position indiquent l'étage où se trouve la cabine.
6. La cabine ne bouge jamais avec la porte ouverte, la porte ne s'ouvre jamais entre deux étages et ne se ferme jamais
   sur quelqu'un.

## Indications

- Verrouillez un bit d'appel par étage à partir de ses boutons palier et cabine ; effacez-le quand la porte est complètement ouverte
  à cet étage.
- Gardez le dernier étage franchi par la cabine dans une variable entière (elle démarre à 1).
- « Ici » est un appel à l'étage où se trouve la cabine ; « au-dessus » et « en dessous » sont des appels plus haut ou plus bas.
- Étapes : 0 repos, 1 ouverture, 2 ouvert (attente), 3 montée, 4 descente, 5 fermeture. Fermer seulement tant que
  l'embrasure est dégagée ; sinon, rouvrir.

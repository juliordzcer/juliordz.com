---
title: Moteur triphasé, étoile-triangle, marche avant et arrière
simulation: motor
level: 3
symbols:
- %I0.0 Marche avant (PB)
- %I0.1 Marche arrière (PB)
- %I0.2 Arrêt (NC, PB)
- %I0.3 Relais thermique OK
- %I0.4 Moteur arrêté
- %Q0.0 KM1 marche avant
- %Q0.1 KM2 marche arrière
- %Q0.2 KM3 étoile
- %Q0.3 KM4 triangle
- %Q0.4 Voyant de marche
- %Q0.5 Voyant de défaut
---
# 25. Moteur triphasé, étoile-triangle, marche avant et arrière

**Objectif :** démarrer un moteur triphasé en étoile puis le commuter en triangle, dans les deux sens,
protégé par un relais thermique, comme le fait un vrai démarreur moteur.

## Entrées et sorties (simulation Moteur triphasé)

| Adresse | Dispositif |
| --- | --- |
| %I0.0 | Marche avant (bouton-poussoir) |
| %I0.1 | Marche arrière (bouton-poussoir) |
| %I0.2 | Arrêt (bouton-poussoir, **normalement fermé**) |
| %I0.3 | Relais thermique OK (contact **normalement fermé** : FALSE en cas de déclenchement) |
| %I0.4 | Moteur arrêté (capteur de vitesse nulle, sous 30 tr/min) |
| %Q0.0, %Q0.1 | KM1 contacteur de ligne marche avant, KM2 contacteur de ligne marche arrière |
| %Q0.2, %Q0.3 | KM3 étoile, KM4 triangle |
| %Q0.4 | Voyant de marche |
| %Q0.5 | Voyant de défaut |

## Exigences

1. La marche avant démarre le moteur en étoile (KM1 + KM3) et commute en triangle (KM1 + KM4)
   quelques secondes plus tard ; la marche arrière fait de même avec KM2.
2. Il ne démarre jamais directement en triangle.
3. Étoile et triangle ne sont jamais enclenchés ensemble ; marche avant et marche arrière ne sont
   jamais enclenchées ensemble.
4. La marche arrière est ignorée tant que le moteur tourne en marche avant (et inversement) :
   arrêter d'abord, et démarrer dans l'autre sens seulement une fois le moteur arrêté.
5. L'arrêt stoppe le moteur.
6. Un déclenchement du relais thermique coupe tous les contacteurs et allume le voyant de défaut ;
   le moteur ne peut pas démarrer tant que le relais n'est pas réarmé.
7. Le voyant de marche est allumé tant que le moteur tourne.

## Indications

- Auto-maintien de chaque contacteur de ligne comme un démarreur moteur ; mettre en série l'arrêt,
  le contact du relais thermique et un contact NC de l'autre sens.
- N'accepter un démarrage que si « Moteur arrêté » est TRUE.
- Un seul temporisateur lancé par l'un ou l'autre contacteur de ligne : étoile pendant sa temporisation,
  triangle à la fin, chacun avec un contact NC de l'autre.

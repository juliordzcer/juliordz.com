---
title: Porte logiche con contatti
simulation: io
level: 1
symbols:
- %I0.0 Ingresso A
- %I0.1 Ingresso B
- %I0.2 Ingresso C
- %I0.3 Ingresso D
- %I0.4 Ingresso E
- %I0.5 Ingresso F
- %I0.6 Ingresso G
- %Q0.0 Uscita AND
- %Q0.1 Uscita OR
- %Q0.2 Uscita NOT
- %Q0.3 Uscita XOR
---
# 1. Porte logiche con contatti

**Obiettivo:** costruire AND, OR, NOT e XOR con contatti `XIC`/`XIO` in serie e in parallelo.

## Ingressi e uscite

| Indirizzo | Uso |
| --- | --- |
| %I0.0, %I0.1 | Ingressi porta AND |
| %I0.2, %I0.3 | Ingressi porta OR |
| %I0.4 | Ingresso invertitore |
| %I0.5, %I0.6 | Ingressi XOR |
| %Q0.0 … %Q0.3 | AND, OR, NOT, XOR |

## Requisiti

1. %Q0.0 si attiva solo quando %I0.0 **e** %I0.1 sono chiusi.
2. %Q0.1 si attiva quando %I0.2 **o** %I0.3 è chiuso.
3. %Q0.2 si attiva quando %I0.4 è **aperto**.
4. %Q0.3 si attiva quando %I0.5 e %I0.6 sono **diversi**.

## Suggerimenti

- Contatti in serie = AND; rami in parallelo = OR; `XIO` = NOT.
- XOR richiede due rami: (A e non B) o (non A e B).

## Come provarlo

Scarica, metti il PLC in RUN e percorri la tabella di verità di ogni porta con gli interruttori.

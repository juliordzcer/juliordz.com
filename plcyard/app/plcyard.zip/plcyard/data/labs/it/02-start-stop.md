---
title: Avvio/arresto con autoritenuta
simulation: io
level: 1
symbols:
- %I0.0 Avvio (NO)
- %I0.1 Arresto (NC)
- %Q0.0 Motore
- %Q0.1 Luce in marcia
- %Q0.2 Luce fermo
---
# 2. Avvio/arresto con autoritenuta

**Obiettivo:** mantenere un motore in marcia dopo che il pulsante di avvio è stato rilasciato.

## Ingressi e uscite

| Indirizzo | Dispositivo | Tipo |
| --- | --- | --- |
| %I0.0 | Avvio | normalmente aperto |
| %I0.1 | Arresto | **normalmente chiuso** |
| %Q0.0 | Motore | |
| %Q0.1 | Luce in marcia | |
| %Q0.2 | Luce fermo | |

## Requisiti

1. Chiudere e aprire Avvio lascia il motore in marcia.
2. Aprire Arresto (premerlo) spegne il motore, anche se Avvio è ancora chiuso.
3. Se il filo di Arresto si rompe, anche il motore deve spegnersi.
4. La luce in marcia segue il motore; la luce fermo è accesa mentre il motore è spento.

## Suggerimenti

- Arresto è NC: quando non è premuto fornisce un 1. Quale istruzione lo esamina?
- Il contatto del motore stesso, in parallelo ad Avvio, è l'autoritenuta.

## Rifletti

Cosa succede al motore se porti il PLC in PGM e poi di nuovo in RUN? Perché?

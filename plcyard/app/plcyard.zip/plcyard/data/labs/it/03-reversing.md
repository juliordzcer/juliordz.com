---
title: Motore reversibile con interblocco
simulation: io
level: 2
symbols:
- %I0.0 Marcia avanti (NO)
- %I0.1 Marcia indietro (NO)
- %I0.2 Arresto (NC)
- %Q0.0 Contattore marcia avanti
- %Q0.1 Contattore marcia indietro
---
# 3. Motore reversibile con interblocco

**Obiettivo:** far girare un motore in due direzioni senza che i due contattori siano mai accesi insieme.

## Requisiti

1. Marcia avanti (%I0.0) avvia e dà autoritenuta a %Q0.0; Marcia indietro (%I0.1) avvia e dà autoritenuta a %Q0.1.
2. Arresto (%I0.2, NC) ferma l'una o l'altra.
3. %Q0.0 e %Q0.1 non devono **mai** essere accesi contemporaneamente.
4. Per cambiare direzione devi prima fermarti: premere Marcia indietro mentre gira in avanti non fa nulla.

## Suggerimenti

- Il segmento (rung) di ciascun contattore include un contatto `XIO` dell'altro (interblocco).

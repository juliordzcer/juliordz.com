---
title: Acceso e spento con un solo pulsante
simulation: io
level: 2
symbols:
- %I0.0 Pulsante (NO, pushbutton)
- %Q0.0 Lampada
---
# 4. Acceso e spento con un solo pulsante

**Obiettivo:** usare un one shot (`ONS`) in modo che ogni pressione cambi lo stato di una lampada.

## Requisiti

1. Ogni pressione di %I0.0 cambia %Q0.0 (acceso ↔ spento).
2. Tenere premuto il pulsante **non** deve far lampeggiare la lampada.

## Suggerimenti

- `ONS` fornisce un impulso di una scansione quando il suo segmento (rung) passa da falso a vero.
- Con quell'impulso e lo stato attuale della lampada puoi costruire un flip-flop a due rami.

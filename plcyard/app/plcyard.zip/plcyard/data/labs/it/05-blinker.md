---
title: Luce lampeggiante con timer
simulation: io
level: 2
symbols:
- %I0.0 Abilitazione
- %Q0.0 Luce lampeggiante
---
# 5. Luce lampeggiante con timer

**Obiettivo:** concatenare due timer TON per generare un segnale periodico.

## Requisiti

1. Con %I0.0 chiuso, %Q0.0 è accesa per 1 s e spenta per 1 s, ripetendosi.
2. Aprendo %I0.0 la luce si spegne e il ciclo riparte.

## Suggerimenti

- Dichiara due tag TIMER (Ctrl+T apre l'elenco dei tag). I preset sono in millisecondi: 1000 è
  1 s, e anche T#1s funziona.
- Il bit DN del secondo timer può azzerare il primo.
- Apri un timer nell'elenco dei tag per osservare i suoi bit EN, TT e DN a bassa velocità.

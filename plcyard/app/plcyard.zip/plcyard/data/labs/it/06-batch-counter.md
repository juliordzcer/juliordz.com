---
title: Contatore di lotti con display
simulation: io
level: 2
symbols:
- %I0.0 Sensore pezzi (NO, pushbutton)
- %I0.1 Azzera lotto (NO, pushbutton)
- %Q0.0 Lotto completo
---
# 6. Contatore di lotti con display

**Obiettivo:** contare i pezzi con CTU, segnalare un lotto completo e mostrare il conteggio sul display BCD.

## Requisiti

1. Ogni impulso su %I0.0 conta un pezzo (un impulso = un pezzo, per quanto duri).
2. A 5 pezzi, %Q0.0 (lotto completo) si accende.
3. %I0.1 azzera il conteggio e spegne %Q0.0.
4. Il display %QW4 mostra sempre il numero di pezzi.

## Suggerimenti

- Il display si aspetta BCD: converti l'accumulatore con `TOD`.

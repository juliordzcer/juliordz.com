---
title: Selezione per intervallo con comparatori
simulation: io
level: 2
symbols:
- %Q0.0 Basso
- %Q0.1 Normale
- %Q0.2 Alto
---
# 7. Selezione per intervallo con comparatori

**Obiettivo:** leggere un numero dalle rotelle (%IW4, BCD) e classificarlo.

## Requisiti

1. Converti il valore di %IW4 in binario in un tag INT (per esempio `Value`).
2. %Q0.0 (Basso) quando il valore è minore di 100.
3. %Q0.1 (Normale) quando è compreso tra 100 e 500, estremi inclusi.
4. %Q0.2 (Alto) quando è maggiore di 500.
5. Solo una delle tre uscite può essere accesa.

## Suggerimenti

- `FRD` converte da BCD a binario.
- `LIM` gestisce "compreso tra" in una sola istruzione.

---
title: Riempimento continuo sulla linea del silo
simulation: silo
level: 2
---
# 8. Riempimento continuo sulla linea del silo

**Obiettivo:** controllare un processo reale: nastro trasportatore, sensore di posizione, valvola e sensore di livello.

## Ingressi e uscite (simulazione Silo)

| Indirizzo | Dispositivo |
| --- | --- |
| %I0.0 | Avvio (pulsante NO) |
| %I0.1 | Arresto (pulsante NC) |
| %I0.3 | Sensore di prossimità: scatola sotto la tramoggia |
| %I0.4 | Sensore di livello: scatola piena |
| %Q0.0 | Motore del nastro trasportatore |
| %Q0.1 | Valvola di riempimento |
| %Q0.2 | Luce in marcia · %Q0.3 Luce riempimento · %Q0.4 Luce pieno |

## Requisiti

1. Avvio e Arresto controllano il sistema in qualsiasi momento; la luce in marcia indica che è in funzione.
2. Ogni scatola si ferma sotto la tramoggia, si riempie e riparte da sola.
3. La luce riempimento è accesa durante il riempimento; la luce pieno dal momento in cui la scatola è piena fino a quando lascia il sensore.
4. Non deve essere versato prodotto.
5. Arresto spegne il motore, la valvola e la luce in marcia.

---
title: Modalità operative con selettore
simulation: silo
level: 3
---
# 9. Modalità operative con selettore

**Obiettivo:** un processo, tre modalità scelte con il selettore A/B/C (%I0.5, %I0.6, %I0.7).

## Requisiti

1. **A — continuo:** come nell'esercizio 8.
2. **B — riavvio manuale:** la scatola piena resta sotto la tramoggia finché l'operatore non preme Avvio
   una volta (un tocco, non tenuto premuto); poi riparte e la scatola successiva si ferma.
3. **C — nessun riempimento:** il nastro gira di continuo e le scatole passano vuote.
4. In tutte e tre le modalità Avvio/Arresto e la luce in marcia funzionano allo stesso modo, e non viene mai versato prodotto.

## Suggerimenti

- In modalità B devi ricordare il tocco su Avvio finché la scatola non lascia il sensore (`OTL`/`OTU` su un tag BOOL).

---
title: Semaforo a due vie senza collisioni
simulation: traffic
level: 3
---
# 10. Semaforo a due vie senza collisioni

**Obiettivo:** sequenziare due semafori con timer in cascata e un intervallo di rosso per entrambi.

## Ingressi e uscite (simulazione Semafori)

| Indirizzo | Uso |
| --- | --- |
| %Q0.0, %Q0.1, %Q0.2 | direzione A: rosso, giallo, verde |
| %Q0.4, %Q0.5, %Q0.6 | direzione B: rosso, giallo, verde |

## Requisiti

1. A: verde 6 s, giallo 2 s; poi rosso mentre B esegue il suo ciclo.
2. B: verde 6 s, giallo 2 s; poi rosso mentre A esegue il suo ciclo.
3. Tra il giallo di una direzione e il verde dell'altra c'è **1 s con entrambi rossi**.
4. In ogni momento ogni direzione ha esattamente una luce accesa.
5. Le auto attraversano senza collisioni (fallo girare per almeno 2 minuti).

## Rifletti

Togli il secondo di rosso per entrambi e osserva: perché a volte le auto si scontrano?

---
title: Livello serbatoio con controllo on/off
simulation: tank
level: 3
symbols:
- %I0.1 Arresto (NC)
---
# 11. Livello serbatoio con controllo on/off

**Obiettivo:** mantenere un serbatoio tra due livelli con una pompa, usando il segnale analogico di livello. È così che funziona un
termostato: acceso sotto un valore, spento sopra un altro.

## Ingressi e uscite (simulazione Serbatoio)

| Indirizzo | Dispositivo |
| --- | --- |
| %I0.0 | Avvio (pulsante NO) |
| %I0.1 | Arresto (pulsante NC) |
| %I0.2 | Galleggiante di livello alto (livello ≥ 90 %) |
| %IW64 | Livello, analogico: 0-27648 = 0-100 % |
| %Q0.0 | Pompa |
| %Q0.1 | Luce in marcia |
| %Q0.2 | Luce allarme alto |

## Requisiti

1. Avvio e Arresto controllano il sistema; la luce in marcia indica che è in funzione.
2. Mentre è in marcia, la pompa parte quando il livello scende sotto il 40 % e si ferma sopra il 60 %.
3. Il livello resta quindi tra circa il 35 % e il 65 %, qualunque sia l'apertura dello scarico.
4. Arresto spegne la pompa.
5. La luce allarme alto è accesa ogni volta che il galleggiante di livello alto è attivo, in marcia o no.

## Suggerimenti

- Il 40 % di 27648 è 11059; il 60 % è 16589.
- Confronta con `LES` e `GRT`, e ricorda lo stato della pompa con `OTL`/`OTU` (o un'autoritenuta): tra
  il 40 % e il 60 % nessuna delle due condizioni è vera, e la pompa deve continuare a fare quello che stava facendo. Quello
  scarto è l'*isteresi*; senza di essa la pompa si accenderebbe e spegnerebbe di continuo.

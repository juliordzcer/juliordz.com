---
title: Livello serbatoio con anello PID
simulation: tank
level: 4
---
# 12. Livello serbatoio con anello PID

**Obiettivo:** mantenere il livello esattamente al setpoint muovendo una valvola proporzionale, e tarare il PID.

## Ingressi e uscite (simulazione Serbatoio)

| Indirizzo | Dispositivo |
| --- | --- |
| %IW64 | Livello, 0-27648 = 0-100 % |
| %IW66 | Manopola setpoint, 0-27648 = 0-100 % |
| %QW64 | Valvola di ingresso, 0-27648 = chiusa a completamente aperta |

## Requisiti

1. Il livello segue la manopola del setpoint: entro ±2 % da esso non oltre 60 s dopo una variazione.
2. Superamento non superiore al 5 %.
3. Quando lo scarico si apre di più (una perturbazione), il livello torna entro ±2 % in 60 s.
4. Il serbatoio non trabocca mai.

## Come fare

1. Aggiungi i tag (Ctrl+T): `LevelPID` di tipo PID, e i tag REAL `Level` e `ValveOut`.
2. Da conteggi grezzi a percentuale: `DIV %IW64 276.48 Level` (27648 / 100), e la manopola in `LevelPID.SP`.
3. `PID LevelPID Level ValveOut` (PID, variabile di processo, variabile di controllo; gli operandi setpoint, tieback,
   master loop e inhold sono opzionali), poi `MUL ValveOut 276.48 %QW64`.
4. Taratura: clic destro sul blocco PID → PID Setup. Nella scheda Tuning inizia con KP 1 e KI 0
   (solo proporzionale): il livello si assesta sotto il setpoint. Poi aggiungi l'azione integrale (KI 0.1,
   poi 0.27 al secondo) e osserva il trend.
5. Più corto: lascia che il PID faccia la scalatura per te. Nella scheda Scaling imposta la PV non scalata a 0-27648, il
   range di ingegneria a 0-100 e la CV a 0-27648; poi `PID LevelPID %IW64 %QW64` con la manopola
   spostata in `LevelPID.SP` è tutto il programma.

## Rifletti

Perché un controllore solo proporzionale lascia qui un offset? Cosa aggiunge il termine integrale?

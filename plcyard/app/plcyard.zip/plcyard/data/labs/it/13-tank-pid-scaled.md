---
title: Livello serbatoio PID, scalato dentro il blocco
simulation: tank
level: 4
---
# 13. Livello serbatoio PID, scalato dentro il blocco

**Obiettivo:** l'anello dell'esercizio 12, ma il PID converte da sé i valori analogici grezzi.

## Ingressi e uscite (simulazione Serbatoio)

| Indirizzo | Dispositivo |
| --- | --- |
| %IW64 | Livello, 0-27648 = 0-100 % |
| %IW66 | Manopola setpoint, 0-27648 = 0-100 % |
| %QW64 | Valvola di ingresso, 0-27648 = chiusa a completamente aperta |

## Requisiti

1. Il livello segue la manopola del setpoint: entro ±2 % da esso non oltre 60 s dopo una variazione.
2. Superamento non superiore al 5 %.
3. Quando lo scarico si apre di più (una perturbazione), il livello torna entro ±2 % in 60 s.
4. Il serbatoio non trabocca mai.

## Come fare

1. Aggiungi i tag `LevelPID` (PID) e `Setpoint` (REAL).
2. PID Setup → Scaling: PV non scalata da 0 a 27648, unità di ingegneria da 0 a 100, CV da 0 a 27648. Tuning:
   KP 4, KI 0.27.
3. La PV è l'ingresso grezzo e la CV l'uscita grezza: `PID LevelPID %IW64 %QW64 Setpoint`.
4. La manopola in percentuale per il setpoint: `SCP %IW66 0 27648 0 100 Setpoint`.

Provalo in tutti e tre i linguaggi: in structured text `LevelPID.PID(PV := %IW64, SP := Setpoint,
CV => %QW64);`, in function block diagram un blocco SCALE che alimenta il pin SP del blocco PID. "Compare
languages" mostra la soluzione di riferimento in ciascuno.

---
title: Due serbatoi in serie
simulation: two_tanks
level: 5
---
# 14. Due serbatoi in serie

**Obiettivo:** mantenere il livello del serbatoio inferiore 2 al setpoint. Puoi aprire solo l'ingresso del
serbatoio superiore 1 e la valvola tra i serbatoi: un processo lento con due ritardi.

## Ingressi e uscite (simulazione Due serbatoi)

| Indirizzo | Dispositivo |
| --- | --- |
| %IW64 | Livello serbatoio 1, 0-27648 = 0-100 % |
| %IW66 | Livello serbatoio 2, 0-27648 = 0-100 % |
| %IW68 | Manopola setpoint, 0-27648 = 0-100 % |
| %QW64 | Valvola di ingresso del serbatoio 1, 0-27648 = 0-100 % |
| %QW66 | Valvola di trasferimento tra i serbatoi, 0-27648 = 0-100 % |
| %I0.2, %I0.3, %I0.4 | Galleggianti alto serbatoio 1, alto serbatoio 2, basso serbatoio 2 |

## Requisiti

1. Il serbatoio 2 mantiene il setpoint (±3 %) entro 3 minuti.
2. Torna al setpoint dopo che lo scarico del serbatoio 2 si apre di più.
3. Segue un nuovo setpoint.
4. Nessuno dei due serbatoi trabocca.

## Suggerimenti

- Un singolo PID dal serbatoio 2 alla valvola di ingresso funziona, ma lentamente. Meglio una **cascata**: il PID
  esterno sul serbatoio 2 fornisce il setpoint di un PID interno sul serbatoio 1 (l'operando master loop
  dell'istruzione `PID`, oppure collega la CV di un PID alla SP dell'altro in FBD).
- Imposta la valvola di trasferimento a un'apertura fissa, per esempio 60 % (`MOV 16589 %QW66`).
- Lascia che ogni PID faccia la scalatura dei valori grezzi: PID Setup → Scaling, non scalata 0-27648.

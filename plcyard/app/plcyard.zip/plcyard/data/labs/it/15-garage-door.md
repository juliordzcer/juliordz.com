---
title: Porta di garage con fotocellula di sicurezza
simulation: garage
level: 3
symbols:
- %I0.0 Apri (PB)
- %I0.1 Chiudi (PB)
- %I0.2 Arresto (NC, PB)
---
# 15. Porta di garage con fotocellula di sicurezza

**Obiettivo:** aprire e chiudere una porta in sicurezza: finecorsa, pulsante di arresto, una fotocellula che
protegge un'auto nel vano, una luce di avvertimento e una luce di cortesia.

## Ingressi e uscite (simulazione Porta di garage)

| Indirizzo | Dispositivo |
| --- | --- |
| %I0.0 | Apri (pulsante) |
| %I0.1 | Chiudi (pulsante) |
| %I0.2 | Arresto (pulsante, **normalmente chiuso**) |
| %I0.3 | Finecorsa di apertura (porta completamente su) |
| %I0.4 | Finecorsa di chiusura (porta completamente giù) |
| %I0.5 | Fotocellula: TRUE finché il fascio è libero |
| %Q0.0, %Q0.1 | Motore su, motore giù |
| %Q0.2 | Luce di avvertimento |
| %Q0.3 | Luce di cortesia |

## Requisiti

1. Apri fa salire la porta e si ferma al finecorsa di apertura; Chiudi la fa scendere fino al finecorsa di chiusura.
2. Arresto ferma la porta dov'è.
3. Se il fascio si interrompe mentre la porta si chiude, la porta risale; Chiudi non fa nulla mentre
   qualcosa è nel vano.
4. La luce di avvertimento lampeggia mentre la porta si muove.
5. La luce di cortesia è accesa mentre la porta si muove e per alcuni secondi dopo che si ferma.
6. Il motore non spinge mai contro un finecorsa e non gira mai nei due sensi contemporaneamente.

## Suggerimenti

- Metti un'autoritenuta su ogni direzione come in un avviatore motore; la direzione opposta e il finecorsa la interrompono.
- Ricorda l'"inversione" con un latch che il finecorsa di apertura azzera.
- Un timer auto-riarmante e un confronto sul suo accumulatore fanno un lampeggiatore; un TOF tiene accesa la luce
  di cortesia.

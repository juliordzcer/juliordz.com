---
title: Sequenza di miscelatore a lotti
simulation: mixer
level: 5
symbols:
- %I0.0 Avvio (PB)
- %I0.1 Arresto (NC, PB)
---
# 16. Sequenza di miscelatore a lotti

**Obiettivo:** una sequenza a passi: riempi due ingredienti, mescola e riscalda, scarica, ripeti.

## Ingressi e uscite (simulazione Miscelatore a lotti)

| Indirizzo | Dispositivo |
| --- | --- |
| %I0.0 | Avvio (pulsante) |
| %I0.1 | Arresto (pulsante, **normalmente chiuso**) |
| %I0.2, %I0.3, %I0.4 | Galleggianti di livello basso (5 %), medio (50 %) e alto (90 %) |
| %IW64 | Temperatura, 0-27648 = 0-100 °C |
| %Q0.0, %Q0.1 | Valvola A, valvola B |
| %Q0.2 | Motore del miscelatore |
| %Q0.3 | Riscaldatore |
| %Q0.4 | Valvola di scarico |
| %Q0.5 | Luce lotto completato |

## Requisiti

1. Avvio esegue i lotti uno dopo l'altro: almeno 2 in 2 minuti.
2. Ogni lotto è buono: A fino al galleggiante medio, B fino al galleggiante alto, mescolato almeno 5 s,
   scaricato a 50-60 °C.
3. La luce lotto completato si accende dopo ogni lotto.
4. Nessun trabocco, nessun riscaldamento senza liquido, nessuna miscelazione a serbatoio vuoto.
5. Arresto spegne tutte le uscite, e nulla riparte finché non si preme Avvio.

## Suggerimenti

- Tieni il passo in un tag intero (0 fermo, 1 riempi A, 2 riempi B, 3 mescola e riscalda, 4 scarica…). Ogni
  uscita è "passo = n"; ogni transizione passa al passo successivo quando la sua condizione è vera.
- Scarica finché il serbatoio è vuoto (il galleggiante basso si disattiva, poi ancora un po').
- Riscalda con isteresi, per esempio acceso sotto 54 °C e spento sopra 56 °C.

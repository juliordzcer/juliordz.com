---
title: Ciclo pick and place
simulation: pick_place
level: 4
symbols:
- %I0.0 Avvio (PB)
- %I0.1 Arresto (NC, PB)
---
# 17. Ciclo pick and place

**Obiettivo:** un braccio pneumatico a due assi con pinza a vuoto sposta i pezzi dall'ingresso a un vassoio, un
ciclo dopo l'altro, in un ordine di movimenti sicuro.

## Ingressi e uscite (simulazione Pick and place)

| Indirizzo | Dispositivo |
| --- | --- |
| %I0.0 | Avvio (pulsante) |
| %I0.1 | Arresto (pulsante, **normalmente chiuso**) |
| %I0.2, %I0.3 | Braccio lato prelievo, braccio lato deposito (cilindro orizzontale) |
| %I0.4, %I0.5 | Braccio su, braccio giù (cilindro verticale) |
| %I0.6 | Pezzo in attesa al punto di prelievo |
| %I0.7 | Vuoto OK: la pinza tiene un pezzo |
| %Q0.0 | Cilindro orizzontale: estendi verso il lato deposito |
| %Q0.1 | Cilindro verticale: giù |
| %Q0.2 | Vuoto |
| %Q0.3 | Lampada di ciclo |

Ogni cilindro impiega un secondo da un estremo all'altro. Un nuovo pezzo arriva un secondo dopo che
l'ultimo è stato prelevato.

## Requisiti

1. Avvio esegue cicli finché arrivano pezzi: giù, afferra, su, attraversa, giù, rilascia, su, torna. Almeno
   5 pezzi depositati in un minuto.
2. Nessun pezzo cade fuori dal vassoio.
3. Il braccio non si muove mai lateralmente mentre è giù.
4. La lampada di ciclo è accesa durante un ciclo.
5. Arresto lascia finire il ciclo in corso con il braccio a casa, e nessun nuovo ciclo parte.

## Suggerimenti

- Un numero di passo (0 casa, 1 giù, 2 afferra, …) rende la sequenza facile da seguire; ogni passo attende
  il suo sensore (braccio giù, vuoto OK, braccio su…) prima del successivo.
- Ogni uscita è una lista di passi: "giù" è acceso nei passi in cui il braccio va o resta giù.
- Dai al rilascio un breve timer (qualche centinaio di ms) prima di sollevare il braccio.
- Solo il passo di casa guarda Run: Arresto quindi termina il lavoro dopo il ciclo in corso.

---
title: Linea di riempimento e tappatura bottiglie
simulation: bottles
level: 4
symbols:
- %I0.0 Avvio (PB)
- %I0.1 Arresto (NC, PB)
---
# 18. Linea di riempimento e tappatura bottiglie

**Obiettivo:** un nastro trasportatore porta le bottiglie sotto un riempitore, un tappatore e una stazione di
ispezione; ferma il nastro per ogni stazione e spingi via le bottiglie difettose.

## Ingressi e uscite (simulazione Linea bottiglie)

| Indirizzo | Dispositivo |
| --- | --- |
| %I0.0 | Avvio (pulsante) |
| %I0.1 | Arresto (pulsante, **normalmente chiuso**) |
| %I0.2 | Bottiglia al riempitore |
| %I0.3 | Bottiglia piena (la bottiglia al riempitore è al 95 % o più) |
| %I0.4 | Bottiglia al tappatore |
| %I0.5 | Bottiglia all'ispezione |
| %I0.6 | La bottiglia all'ispezione è buona |
| %Q0.0 | Nastro trasportatore |
| %Q0.1 | Valvola di riempimento |
| %Q0.2 | Pressa del tappatore |
| %Q0.3 | Espulsore degli scarti |
| %Q0.4 | Lampada di marcia |

Una bottiglia resta sotto una stazione solo se il nastro si ferma mentre il sensore della stazione la vede. La
pressa ha bisogno di mezzo secondo su una bottiglia per tapparla. Ogni quinta bottiglia ha un tappo difettoso.

## Requisiti

1. Avvio fa funzionare la linea: almeno 8 bottiglie buone spedite in 2 minuti.
2. Nessuna bottiglia difettosa viene spedita.
3. Le bottiglie difettose vengono scartate all'ispezione; quelle buone no.
4. Nessuna fuoriuscita, nessun trabocco, nessuna tappatura di una bottiglia in movimento.
5. La lampada di marcia è accesa mentre la linea funziona.
6. Arresto spegne il nastro, il riempitore, il tappatore e la lampada di marcia.

## Suggerimenti

- Il nastro gira a meno che una stazione stia lavorando: "riempimento" è una bottiglia al riempitore che non è
  ancora piena; "tappatura" è una bottiglia al tappatore durante i primi 0.6 s (un TON sul sensore).
- Riempi solo mentre il nastro è fermo.
- L'espulsore degli scarti è semplicemente "una bottiglia all'ispezione che non è buona".

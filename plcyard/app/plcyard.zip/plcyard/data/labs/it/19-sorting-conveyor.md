---
title: Smistamento scatole per dimensione
simulation: sorter
level: 5
symbols:
- %I0.0 Avvio (PB)
- %I0.1 Arresto (NC, PB)
---
# 19. Smistamento scatole per dimensione

**Obiettivo:** misurare ogni scatola con due barriere luminose e spingerla nel contenitore della sua dimensione, più avanti
sul nastro, mentre altre scatole sono già in arrivo.

## Ingressi e uscite (simulazione Nastro di smistamento)

| Indirizzo | Dispositivo |
| --- | --- |
| %I0.0 | Avvio (pulsante) |
| %I0.1 | Arresto (pulsante, **normalmente chiuso**) |
| %I0.2 | Scatola al punto di misura |
| %I0.3 | Barriera bassa interrotta (scatola media o grande) |
| %I0.4 | Barriera alta interrotta (scatola grande) |
| %I0.5, %I0.6, %I0.7 | Scatola davanti all'espulsore 1, 2, 3 |
| %Q0.0 | Nastro trasportatore |
| %Q0.1, %Q0.2, %Q0.3 | Espulsore 1 (piccola), espulsore 2 (media), espulsore 3 (grande) |
| %Q0.4 | Lampada di marcia |

Le scatole arrivano piccola, grande, media, media, piccola, grande, … Una scatola che raggiunge la fine del nastro
cade giù.

## Requisiti

1. Avvio fa girare il nastro: almeno 15 scatole smistate in 90 secondi.
2. Ogni scatola finisce nel contenitore della sua dimensione.
3. Nessuna scatola cade dalla fine del nastro.
4. La lampada di marcia è accesa mentre il nastro gira.
5. Arresto ferma il nastro e spegne la lampada di marcia.

## Suggerimenti

- Diverse scatole sono tra le barriere e gli espulsori contemporaneamente, quindi ricorda le dimensioni in ordine:
  una coda (un array e un indice di scrittura) per ogni tratto di nastro.
- Quando una nuova scatola raggiunge il punto di misura (fronte di salita), la sua dimensione è 1, o 2 se la barriera bassa è
  interrotta, o 3 se anche quella alta è interrotta; scrivila nella coda per l'espulsore 1.
- Quando una scatola raggiunge l'espulsore k (fronte di salita), leggi la prossima dimensione dalla coda k: spingila se è
  la dimensione k, altrimenti scrivila nella coda k+1.
- Gli indirizzi indicizzati funzionano ovunque: `Q1[W1]` in un MOV, in un blocco MOVE o in structured text.

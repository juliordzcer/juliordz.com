---
title: Barriere e contatore di un parcheggio
simulation: parking
level: 3
symbols: []
---
# 20. Barriere e contatore di un parcheggio

**Obiettivo:** far entrare e uscire le auto con due barriere, contarle e mostrare i posti liberi; tieni le auto
fuori quando il parcheggio è pieno.

## Ingressi e uscite (simulazione Parcheggio)

| Indirizzo | Dispositivo |
| --- | --- |
| %I0.0 | Auto in attesa all'ingresso |
| %I0.1 | Auto che passa la barriera d'ingresso (barriera luminosa) |
| %I0.2 | Auto in attesa all'uscita |
| %I0.3 | Auto che passa la barriera d'uscita (barriera luminosa) |
| %I0.4, %I0.5 | Barriera d'ingresso su, barriera d'uscita su |
| %Q0.0 | Alza la barriera d'ingresso |
| %Q0.1 | Alza la barriera d'uscita |
| %Q0.2 | Cartello PIENO |
| %QW4 | Display posti liberi (BCD) |

Il parcheggio ha dieci posti e **all'avvio ci sono tre auto parcheggiate**. Le auto arrivano con i pulsanti "Car
arrives" e "Car leaves" (o con Traffic).

## Requisiti

1. Il display mostra i posti liberi fin dall'inizio (7).
2. Un'auto in attesa all'ingresso riceve la barriera; questa scende una volta che l'auto è entrata.
3. Le auto che entrano vengono contate sul display.
4. Un'auto che esce riceve la barriera d'uscita e viene contata.
5. PIENO si accende con dieci auto dentro.
6. Con il parcheggio pieno la barriera d'ingresso resta giù per un'auto in attesa.
7. Quando un'auto esce, l'auto in attesa entra.
8. Nessuna barriera scende su un'auto.

## Suggerimenti

- Tieni il numero di auto in un tag intero che parte da 3 (il suo valore iniziale nella lista dei tag).
- Metti un latch su "alza" quando un'auto attende (all'ingresso solo se c'è posto), azzeralo sul fronte di
  discesa della barriera luminosa: è quando l'auto è passata, e il momento di contarla.
- Mostra `10 - count` con una conversione BCD (TOD) sulla parola del display.

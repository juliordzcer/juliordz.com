---
title: Stazione di pompaggio con rotazione
simulation: pumps
level: 4
symbols:
- %I0.0 Reset allarme (PB)
- %I0.1 Arresto (NC, PB)
---
# 21. Stazione di pompaggio con rotazione

**Obiettivo:** due pompe svuotano una vasca. Si alternano per usurarsi in modo uniforme, la seconda aiuta quando
il livello continua a salire, e una pompa guasta viene sostituita dall'altra.

## Ingressi e uscite (simulazione Stazione di pompaggio)

| Indirizzo | Dispositivo |
| --- | --- |
| %I0.0 | Reset allarme (pulsante) |
| %I0.1 | Arresto (pulsante, **normalmente chiuso**) |
| %I0.2 | Livello basso (15 % o più) |
| %I0.3 | Livello di avvio (50 % o più) |
| %I0.4 | Livello alto (75 % o più) |
| %I0.5 | Livello di allarme troppopieno (95 % o più) |
| %I0.6, %I0.7 | Guasto pompa 1, guasto pompa 2 (TRUE quando è scattata la protezione della pompa) |
| %IW64 | Livello, 0-27648 = 0-100 % |
| %Q0.0, %Q0.1 | Pompa 1, pompa 2 |
| %Q0.2 | Lampada di allarme |

Ogni pompa estrae il 3 % della vasca al secondo. Il cursore dell'afflusso arriva fino al 5 % al secondo, più
di quanto una pompa possa gestire.

## Requisiti

1. Le pompe mantengono il livello tra basso e alto: una pompa parte al livello di avvio e si ferma al
   livello basso.
2. Si alternano: ogni nuovo ciclo di svuotamento usa l'altra pompa.
3. Entrambe le pompe funzionano quando il livello continua a salire fino al livello alto.
4. Una pompa guasta viene spenta e l'altra prende il sopravvento.
5. La lampada di allarme si accende per un guasto di una pompa o per il livello di troppopieno.
6. Reset cancella l'allarme solo quando il guasto è sparito.
7. Nessun troppopieno e nessuna pompa che gira a secco.
8. Arresto (tenuto premuto) spegne entrambe le pompe.

## Suggerimenti

- Ricorda quale pompa è la principale in un tag intero (1 o 2) e cambiala all'inizio di ogni ciclo:
  `Lead := 3 - Lead`.
- Un ciclo inizia quando nessuna pompa gira e si raggiunge il livello di avvio; termina al livello basso.
- Al livello alto, fai funzionare ogni pompa che non è guasta.
- Metti un latch sull'allarme; azzeralo con Reset solo quando non ci sono guasti né livello di troppopieno.

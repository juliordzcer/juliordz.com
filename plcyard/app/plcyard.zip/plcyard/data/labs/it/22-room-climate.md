---
title: Clima ambiente con riscaldamento e raffreddamento
simulation: hvac
level: 5
symbols:
- %I0.0 Acceso (PB)
- %I0.1 Spento (NC, PB)
---
# 22. Clima ambiente con riscaldamento e raffreddamento

**Obiettivo:** mantenere una stanza alla temperatura della manopola setpoint con un riscaldatore e un raffreddatore, entrambi
analogici, mai entrambi insieme e mai senza la ventola.

## Ingressi e uscite (simulazione Clima ambiente)

| Indirizzo | Dispositivo |
| --- | --- |
| %I0.0 | Sistema acceso (pulsante) |
| %I0.1 | Sistema spento (pulsante, **normalmente chiuso**) |
| %I0.2 | Finestra aperta |
| %I0.3 | Flusso d'aria: la ventola sta girando |
| %IW64 | Temperatura stanza, 0-27648 = 0-50 °C |
| %IW66 | Manopola setpoint, 0-27648 = 0-50 °C |
| %Q0.0 | Ventola |
| %Q0.1 | Lampada di riscaldamento |
| %Q0.2 | Lampada di raffreddamento |
| %QW64 | Riscaldatore, 0-27648 = 0-100 % |
| %QW66 | Raffreddatore, 0-27648 = 0-100 % |

La stanza parte a 16 °C con 8 °C fuori. Riscaldare o raffreddare senza la ventola surriscalda la batteria
(la simulazione lo ignora e lo segnala); riscaldare e raffreddare insieme spreca solo energia.

## Requisiti

1. Acceso avvia la ventola e porta la stanza al setpoint (±0.5 °C) entro 2 minuti.
2. Mantiene la temperatura (±1 °C) con la finestra aperta e 18 °C fuori.
3. Raffredda quando fuori fa caldo (35 °C), entro ±1 °C.
4. Segue un nuovo setpoint (24 °C) entro ±1 °C.
5. Le lampade di riscaldamento e raffreddamento mostrano cosa sta funzionando.
6. Non riscalda e raffredda mai insieme, e mai senza la ventola.
7. Spento ferma la ventola, il riscaldatore e il raffreddatore.

## Suggerimenti

- Un solo PID può pilotare entrambi: lascia che la sua uscita vada da -100 % (raffreddamento massimo) a +100 % (riscaldamento massimo)
  con il minimo di uscita del tag PID impostato a -100. Il riscaldatore riceve la parte positiva, il
  raffreddatore la parte negativa.
- Scala la stanza e il setpoint in °C (0-27648 → 0-50) e le uscite al contrario (0-100 % →
  0-27648).
- Niente flusso d'aria, niente riscaldamento o raffreddamento: forza la richiesta a 0 quando la ventola non è confermata.

---
title: Programma della lavatrice
simulation: washer
level: 5
symbols:
- %I0.0 Avvio (PB)
- %I0.1 Arresto (NC, PB)
---
# 23. Programma della lavatrice

**Obiettivo:** una sequenza temporizzata con interblocchi di sicurezza: blocca lo sportello, riempi, lava alternando i due sensi,
scarica, centrifuga, attendi che il cestello si fermi, sblocca.

## Ingressi e uscite (simulazione Lavatrice)

| Indirizzo | Dispositivo |
| --- | --- |
| %I0.0 | Avvio (pulsante) |
| %I0.1 | Arresto (pulsante, **normalmente chiuso**) |
| %I0.2 | Sportello chiuso |
| %I0.3 | Sportello bloccato |
| %I0.4 | Acqua presente (10 % o più) |
| %I0.5 | Acqua piena (80 % o più) |
| %I0.6 | Cestello fermo |
| %Q0.0 | Blocco sportello |
| %Q0.1 | Valvola di riempimento |
| %Q0.2, %Q0.3 | Lavaggio senso sinistra, lavaggio senso destra |
| %Q0.4 | Centrifuga |
| %Q0.5 | Pompa di scarico |
| %Q0.6 | Lampada fine ciclo |

Il cestello accelera e decelera a 400 giri/min al secondo: dopo una centrifuga impiega qualche secondo a
fermarsi.

## Requisiti

1. Avvio con lo sportello chiuso esegue un lavaggio completo entro 2 minuti.
2. I panni girano in acqua almeno 10 s per ciascun senso.
3. L'acqua viene scaricata prima di una centrifuga di almeno 5 s.
4. La lampada fine ciclo si accende alla fine.
5. Avvio non fa nulla con lo sportello aperto.
6. Arresto durante un lavaggio ferma il cestello e sblocca lo sportello una volta che il cestello si è fermato.
7. Lo sportello non si sblocca mai mentre il cestello gira, e la macchina non allaga mai.

## Suggerimenti

- Un numero di passo: 0 fermo, 1 blocco, 2 riempi, 3 lava, 4 scarica, 5 centrifuga, 6 attendi il cestello, 7 fine.
- Nel passo di lavaggio un timer di qualche secondo che si riavvia da solo inverte il senso.
- Scarica finché il sensore "acqua presente" si disattiva, poi ancora un po'.
- Arresto salta a "attendi il cestello" da qualsiasi passo che fa funzionare qualcosa.

---
title: Ascensore a tre piani
simulation: elevator
level: 5
symbols: []
---
# 24. Ascensore a tre piani

**Obiettivo:** servire le chiamate dal pianerottolo e dalla cabina su tre piani: ricorda ogni chiamata, raggiungila, fermati a livello
con il piano, apri e chiudi la porta in sicurezza.

## Ingressi e uscite (simulazione Ascensore)

| Indirizzo | Dispositivo |
| --- | --- |
| %I0.0, %I0.1, %I0.2 | Pulsanti di chiamata dal pianerottolo, piani 1-3 |
| %I0.3, %I0.4, %I0.5 | Pulsanti in cabina, piani 1-3 |
| %I0.6, %I0.7, %I1.0 | Cabina al piano 1, 2, 3 |
| %I1.1 | Finecorsa porta aperta |
| %I1.2 | Finecorsa porta chiusa |
| %I1.3 | Bordo di sicurezza porta libero (TRUE a meno che qualcuno sia nel vano porta) |
| %I1.4 | Oltrepasso superiore OK |
| %I1.5 | Oltrepasso inferiore OK |
| %Q0.0, %Q0.1 | Motore su, motore giù |
| %Q0.2, %Q0.3 | Porta apri, porta chiudi |
| %Q0.4, %Q0.5, %Q0.6 | Lampade di posizione, piani 1-3 |

La cabina parte al piano 1 con la porta chiusa. Impiega 3 s per un piano; la porta si apre o si
chiude in 2 s.

## Requisiti

1. Una chiamata dal pianerottolo porta la cabina e apre la porta a quel piano.
2. Un pulsante in cabina porta la cabina al suo piano.
3. Le chiamate vengono ricordate (i pulsanti sono premuti solo per un momento) e tutte servite.
4. La porta si riapre, o resta aperta, mentre qualcuno è nel vano porta.
5. Le lampade di posizione mostrano il piano a cui si trova la cabina.
6. La cabina non si muove mai con la porta aperta, la porta non si apre mai tra i piani e non si chiude mai
   su qualcuno.

## Suggerimenti

- Metti un latch su un bit di chiamata per piano dai suoi pulsanti di pianerottolo e di cabina; azzeralo quando la porta è completamente aperta
  a quel piano.
- Tieni l'ultimo piano superato dalla cabina in un tag intero (parte da 1).
- "Qui" è una chiamata al piano in cui si trova la cabina; "sopra" e "sotto" sono chiamate più in alto o più in basso.
- Passi: 0 fermo, 1 apertura, 2 aperta (attesa), 3 salita, 4 discesa, 5 chiusura. Chiudi solo mentre
  il vano porta è libero; se non lo è, riapri.

---
title: Motore trifase, stella-triangolo, marcia avanti e indietro
simulation: motor
level: 3
symbols:
- %I0.0 Marcia avanti (PB)
- %I0.1 Marcia indietro (PB)
- %I0.2 Arresto (NC, PB)
- %I0.3 Relè termico OK
- %I0.4 Motore fermo
- %Q0.0 KM1 marcia avanti
- %Q0.1 KM2 marcia indietro
- %Q0.2 KM3 stella
- %Q0.3 KM4 triangolo
- %Q0.4 Lampada di marcia
- %Q0.5 Lampada di guasto
---
# 25. Motore trifase, stella-triangolo, marcia avanti e indietro

**Obiettivo:** avviare un motore trifase in stella e commutarlo in triangolo, in entrambe le direzioni, protetto da
un relè termico, come fa un vero avviatore motore.

## Ingressi e uscite (simulazione Motore trifase)

| Indirizzo | Dispositivo |
| --- | --- |
| %I0.0 | Marcia avanti (pulsante) |
| %I0.1 | Marcia indietro (pulsante) |
| %I0.2 | Arresto (pulsante, **normalmente chiuso**) |
| %I0.3 | Relè termico OK (contatto **normalmente chiuso**: FALSE quando scattato) |
| %I0.4 | Motore fermo (sensore di zero giri, sotto 30 giri/min) |
| %Q0.0, %Q0.1 | KM1 contattore di linea marcia avanti, KM2 contattore di linea marcia indietro |
| %Q0.2, %Q0.3 | KM3 stella, KM4 triangolo |
| %Q0.4 | Lampada di marcia |
| %Q0.5 | Lampada di guasto |

## Requisiti

1. La marcia avanti avvia il motore in stella (KM1 + KM3) e commuta in triangolo (KM1 + KM4) dopo qualche secondo;
   la marcia indietro fa lo stesso con KM2.
2. Non parte mai direttamente in triangolo.
3. Stella e triangolo non sono mai attivi insieme; marcia avanti e marcia indietro non sono mai attive insieme.
4. La marcia indietro è ignorata mentre il motore gira in avanti (e viceversa): prima fermare, e
   avviare nell'altra direzione solo quando il motore si è fermato.
5. L'arresto ferma il motore.
6. Lo scatto del relè termico disinserisce ogni contattore e accende la lampada di guasto; il motore non può partire finché
   il relè non viene riarmato.
7. La lampada di marcia è accesa mentre il motore gira.

## Suggerimenti

- Autoritenere ogni contattore di linea come in un avviatore motore; mettere in serie Arresto, il contatto del relè termico e un contatto
  NC dell'altra direzione.
- Accettare un avvio solo mentre "Motore fermo" è TRUE.
- Un timer avviato da uno dei due contattori di linea: stella mentre è in corso, triangolo al termine, ciascuno con
  un contatto NC dell'altro.

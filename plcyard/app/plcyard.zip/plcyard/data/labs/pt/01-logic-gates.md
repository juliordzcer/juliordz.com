---
title: Portas lógicas com contatos
simulation: io
level: 1
symbols:
- %I0.0 Entrada A
- %I0.1 Entrada B
- %I0.2 Entrada C
- %I0.3 Entrada D
- %I0.4 Entrada E
- %I0.5 Entrada F
- %I0.6 Entrada G
- %Q0.0 Saída AND
- %Q0.1 Saída OR
- %Q0.2 Saída NOT
- %Q0.3 Saída XOR
---
# 1. Portas lógicas com contatos

**Objetivo:** montar AND, OR, NOT e XOR com contatos `XIC`/`XIO` em série e em paralelo.

## Entradas e saídas

| Endereço | Uso |
| --- | --- |
| %I0.0, %I0.1 | Entradas da porta AND |
| %I0.2, %I0.3 | Entradas da porta OR |
| %I0.4 | Entrada do inversor |
| %I0.5, %I0.6 | Entradas da XOR |
| %Q0.0 … %Q0.3 | AND, OR, NOT, XOR |

## Requisitos

1. %Q0.0 liga somente quando %I0.0 **e** %I0.1 estão fechados.
2. %Q0.1 liga quando %I0.2 **ou** %I0.3 está fechado.
3. %Q0.2 liga quando %I0.4 está **aberto**.
4. %Q0.3 liga quando %I0.5 e %I0.6 são **diferentes**.

## Dicas

- Contatos em série = AND; ramos em paralelo = OR; `XIO` = NOT.
- XOR precisa de dois ramos: (A e não B) ou (não A e B).

## Como testar

Baixe o programa, coloque o PLC em RUN e percorra a tabela verdade de cada porta com os interruptores.

---
title: Partida/parada com selo
simulation: io
level: 1
symbols:
- %I0.0 Partida (NO)
- %I0.1 Parada (NC)
- %Q0.0 Motor
- %Q0.1 Luz de funcionamento
- %Q0.2 Luz de parado
---
# 2. Partida/parada com selo

**Objetivo:** manter um motor funcionando depois que o botão de partida é solto.

## Entradas e saídas

| Endereço | Dispositivo | Tipo |
| --- | --- | --- |
| %I0.0 | Partida | normalmente aberto |
| %I0.1 | Parada | **normalmente fechado** |
| %Q0.0 | Motor | |
| %Q0.1 | Luz de funcionamento | |
| %Q0.2 | Luz de parado | |

## Requisitos

1. Fechar e abrir a Partida deixa o motor funcionando.
2. Abrir a Parada (pressioná-la) desliga o motor, mesmo que a Partida ainda esteja fechada.
3. Se o fio da Parada romper, o motor também deve desligar.
4. A luz de funcionamento acompanha o motor; a luz de parado fica acesa enquanto o motor está desligado.

## Dicas

- A Parada é NC: quando não está pressionada, entrega um 1. Qual instrução a examina?
- O próprio contato do motor, em paralelo com a Partida, é o selo.

## Pense nisso

O que acontece com o motor se você colocar o PLC em PGM e voltar para RUN? Por quê?

---
title: Motor com reversão e intertravamento
simulation: io
level: 2
symbols:
- %I0.0 Avanço (NO)
- %I0.1 Ré (NO)
- %I0.2 Parada (NC)
- %Q0.0 Contator de avanço
- %Q0.1 Contator de ré
---
# 3. Motor com reversão e intertravamento

**Objetivo:** fazer um motor girar nos dois sentidos sem que os dois contatores fiquem ligados ao mesmo tempo.

## Requisitos

1. Avanço (%I0.0) parte e sela em %Q0.0; Ré (%I0.1) parte e sela em %Q0.1.
2. Parada (%I0.2, NC) para qualquer um dos dois.
3. %Q0.0 e %Q0.1 **nunca** podem ficar ligados ao mesmo tempo.
4. Para trocar de sentido é preciso parar antes: pressionar Ré enquanto gira em avanço não faz nada.

## Dicas

- A linha de cada contator inclui um contato `XIO` do outro (intertravamento).

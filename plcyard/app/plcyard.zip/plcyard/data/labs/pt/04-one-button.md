---
title: Liga e desliga com um só botão
simulation: io
level: 2
symbols:
- %I0.0 Botão (NO, botão)
- %Q0.0 Lâmpada
---
# 4. Liga e desliga com um só botão

**Objetivo:** use um one shot (`ONS`) para que cada pressionamento mude o estado de uma lâmpada.

## Requisitos

1. Cada pressionamento de %I0.0 muda %Q0.0 (liga ↔ desliga).
2. Manter o botão pressionado **não** deve fazer a lâmpada piscar.

## Dicas

- `ONS` gera um pulso de um scan quando sua linha passa de falsa para verdadeira.
- Com esse pulso e o estado atual da lâmpada você pode montar um flip-flop de duas ramificações.

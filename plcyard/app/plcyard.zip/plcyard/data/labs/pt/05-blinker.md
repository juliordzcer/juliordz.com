---
title: Luz piscante com temporizadores
simulation: io
level: 2
symbols:
- %I0.0 Habilitação
- %Q0.0 Luz piscante
---
# 5. Luz piscante com temporizadores

**Objetivo:** encadear dois temporizadores TON para gerar um sinal periódico.

## Requisitos

1. Com %I0.0 fechado, %Q0.0 fica ligado por 1 s e desligado por 1 s, repetindo.
2. Abrir %I0.0 desliga a luz e reinicia o ciclo.

## Dicas

- Declare dois tags TIMER (Ctrl+T abre a lista de tags). Os presets estão em milissegundos: 1000 é
  1 s, e T#1s também funciona.
- O bit DN do segundo temporizador pode reiniciar o primeiro.
- Abra um temporizador na lista de tags para acompanhar seus bits EN, TT e DN em velocidade baixa.

---
title: Contador de lotes com display
simulation: io
level: 2
symbols:
- %I0.0 Sensor de peça (NO, botão)
- %I0.1 Reset do lote (NO, botão)
- %Q0.0 Lote completo
---
# 6. Contador de lotes com display

**Objetivo:** contar peças com CTU, sinalizar um lote completo e mostrar a contagem no display BCD.

## Requisitos

1. Cada pulso em %I0.0 conta uma peça (um pulso = uma peça, independentemente de quanto dure).
2. Em 5 peças, %Q0.0 (lote completo) liga.
3. %I0.1 reinicia a contagem e desliga %Q0.0.
4. O display %QW4 sempre mostra o número de peças.

## Dicas

- O display espera BCD: converta o acumulador com `TOD`.

---
title: Classificação por faixa com comparadores
simulation: io
level: 2
symbols:
- %Q0.0 Baixo
- %Q0.1 Normal
- %Q0.2 Alto
---
# 7. Classificação por faixa com comparadores

**Objetivo:** ler um número das chaves de polegar (%IW4, BCD) e classificá-lo.

## Requisitos

1. Converta o valor de %IW4 para binário em uma tag INT (por exemplo `Value`).
2. %Q0.0 (Baixo) quando o valor for menor que 100.
3. %Q0.1 (Normal) quando estiver entre 100 e 500, inclusive.
4. %Q0.2 (Alto) quando for maior que 500.
5. Apenas uma das três saídas pode estar ligada.

## Dicas

- `FRD` converte de BCD para binário.
- `LIM` trata o "entre" em uma única instrução.

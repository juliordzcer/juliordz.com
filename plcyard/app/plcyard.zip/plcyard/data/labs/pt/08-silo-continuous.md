---
title: Enchimento contínuo na linha do silo
simulation: silo
level: 2
---
# 8. Enchimento contínuo na linha do silo

**Objetivo:** controlar um processo real: esteira, sensor de posição, válvula e sensor de nível.

## Entradas e saídas (simulação Silo)

| Endereço | Dispositivo |
| --- | --- |
| %I0.0 | Início (botão NO) |
| %I0.1 | Parada (botão NC) |
| %I0.3 | Sensor de proximidade: caixa sob o silo |
| %I0.4 | Sensor de nível: caixa cheia |
| %Q0.0 | Motor da esteira |
| %Q0.1 | Válvula de enchimento |
| %Q0.2 | Luz de operação · %Q0.3 Luz de enchimento · %Q0.4 Luz de cheia |

## Requisitos

1. Início e Parada controlam o sistema a qualquer momento; a Luz de operação mostra que ele está em funcionamento.
2. Cada caixa para sob o silo, enche e segue sozinha.
3. A Luz de enchimento fica acesa durante o enchimento; a Luz de cheia, do momento em que a caixa fica cheia até ela sair do sensor.
4. Nenhum produto pode ser derramado.
5. Parada desliga o motor, a válvula e a Luz de operação.

---
title: Modos de operação com seletor
simulation: silo
level: 3
---
# 9. Modos de operação com seletor

**Objetivo:** um processo, três modos escolhidos com o seletor A/B/C (%I0.5, %I0.6, %I0.7).

## Requisitos

1. **A — contínuo:** como no exercício 8.
2. **B — reinício manual:** a caixa cheia fica sob o silo até o operador pressionar Início
   uma vez (um toque, não mantido); então ela segue e a próxima caixa para.
3. **C — sem enchimento:** a esteira roda continuamente e as caixas passam vazias.
4. Nos três modos, Início/Parada e a Luz de operação funcionam igual, e nenhum produto é derramado.

## Dicas

- No modo B você precisa memorizar o toque em Início até a caixa sair do sensor (`OTL`/`OTU` em uma tag BOOL).

---
title: Semáforo de dois sentidos sem colisões
simulation: traffic
level: 3
---
# 10. Semáforo de dois sentidos sem colisões

**Objetivo:** sequenciar dois semáforos com temporizadores em cascata e um intervalo de vermelho para todos.

## Entradas e saídas (simulação Traffic lights)

| Endereço | Uso |
| --- | --- |
| %Q0.0, %Q0.1, %Q0.2 | sentido A: vermelho, amarelo, verde |
| %Q0.4, %Q0.5, %Q0.6 | sentido B: vermelho, amarelo, verde |

## Requisitos

1. A: verde 6 s, amarelo 2 s; depois vermelho enquanto B executa seu ciclo.
2. B: verde 6 s, amarelo 2 s; depois vermelho enquanto A executa seu ciclo.
3. Entre o amarelo de um sentido e o verde do outro há **1 s com ambos em vermelho**.
4. A cada momento cada sentido tem exatamente uma luz acesa.
5. Os carros atravessam sem colidir (execute por pelo menos 2 minutos).

## Pense nisso

Remova o segundo de vermelho para todos e observe: por que os carros às vezes colidem?

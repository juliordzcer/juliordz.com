---
title: Nível de tanque com controle liga/desliga
simulation: tank
level: 3
symbols:
- %I0.1 Parada (NC)
---
# 11. Nível de tanque com controle liga/desliga

**Objetivo:** manter um tanque entre dois níveis com uma bomba, usando o sinal analógico de nível. É assim que um
termostato funciona: liga abaixo de um valor, desliga acima de outro.

## Entradas e saídas (simulação Tank)

| Endereço | Dispositivo |
| --- | --- |
| %I0.0 | Início (botão NO) |
| %I0.1 | Parada (botão NC) |
| %I0.2 | Chave de nível alto (nível ≥ 90 %) |
| %IW64 | Nível, analógico: 0-27648 = 0-100 % |
| %Q0.0 | Bomba |
| %Q0.1 | Luz de marcha |
| %Q0.2 | Luz de alarme alto |

## Requisitos

1. Início e Parada controlam o sistema; a luz de marcha indica que ele está em funcionamento.
2. Enquanto estiver em funcionamento, a bomba liga quando o nível cai abaixo de 40 % e desliga acima de 60 %.
3. O nível então fica entre cerca de 35 % e 65 %, qualquer que seja a abertura da saída.
4. Parada desliga a bomba.
5. A luz de alarme alto fica acesa sempre que a chave de nível alto estiver acionada, em funcionamento ou não.

## Pistas

- 40 % de 27648 é 11059; 60 % é 16589.
- Compare com `LES` e `GRT`, e lembre o estado da bomba com `OTL`/`OTU` (ou um selo): entre
  40 % e 60 % nenhuma condição é verdadeira, e a bomba deve continuar fazendo o que já estava fazendo. Essa
  faixa é a *histerese*; sem ela a bomba ficaria ligando e desligando sem parar.

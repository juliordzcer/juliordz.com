---
title: Nível de tanque com malha PID
simulation: tank
level: 4
---
# 12. Nível de tanque com malha PID

**Objetivo:** manter o nível exatamente no setpoint movendo uma válvula proporcional, e ajustar o PID.

## Entradas e saídas (simulação Tank)

| Endereço | Dispositivo |
| --- | --- |
| %IW64 | Nível, 0-27648 = 0-100 % |
| %IW66 | Botão de setpoint, 0-27648 = 0-100 % |
| %QW64 | Válvula de entrada, 0-27648 = fechada a totalmente aberta |

## Requisitos

1. O nível segue o botão de setpoint: dentro de ±2 % dele no máximo 60 s após uma mudança.
2. Sobressinal (overshoot) de no máximo 5 %.
3. Quando a saída abre mais (uma perturbação), o nível volta a ficar dentro de ±2 % em 60 s.
4. O tanque nunca transborda.

## Como fazer

1. Adicione tags (Ctrl+T): `LevelPID` do tipo PID, e as tags REAL `Level` e `ValveOut`.
2. Contagens brutas para porcento: `DIV %IW64 276.48 Level` (27648 / 100), e o botão em `LevelPID.SP`.
3. `PID LevelPID Level ValveOut` (PID, variável de processo, variável de controle; os operandos setpoint, tieback,
   malha mestre e inhold são opcionais), depois `MUL ValveOut 276.48 %QW64`.
4. Ajuste: clique com o botão direito na caixa PID → PID Setup. Na aba Tuning comece com KP 1 e KI 0
   (somente proporcional): o nível se estabiliza abaixo do setpoint. Depois adicione ação integral (KI 0.1,
   depois 0.27 por segundo) e observe a tendência.
5. Mais curto: deixe o PID fazer a escala para você. Na aba Scaling defina a PV não escalada como 0-27648, a
   faixa de engenharia como 0-100 e a CV como 0-27648; então `PID LevelPID %IW64 %QW64` com o botão
   movido para `LevelPID.SP` é o programa inteiro.

## Pense nisso

Por que um controlador apenas proporcional deixa um offset aqui? O que o termo integral acrescenta?

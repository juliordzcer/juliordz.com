---
title: Nível de tanque PID, escalado dentro do bloco
simulation: tank
level: 4
---
# 13. Nível de tanque PID, escalado dentro do bloco

**Objetivo:** a malha do exercício 12, mas o PID converte os valores analógicos brutos por conta própria.

## Entradas e saídas (simulação Tank)

| Endereço | Dispositivo |
| --- | --- |
| %IW64 | Nível, 0-27648 = 0-100 % |
| %IW66 | Botão de setpoint, 0-27648 = 0-100 % |
| %QW64 | Válvula de entrada, 0-27648 = fechada a totalmente aberta |

## Requisitos

1. O nível segue o botão de setpoint: dentro de ±2 % dele no máximo 60 s após uma mudança.
2. Sobressinal (overshoot) de no máximo 5 %.
3. Quando a saída abre mais (uma perturbação), o nível volta a ficar dentro de ±2 % em 60 s.
4. O tanque nunca transborda.

## Como fazer

1. Adicione as tags `LevelPID` (PID) e `Setpoint` (REAL).
2. PID Setup → Scaling: PV não escalada de 0 a 27648, unidades de engenharia de 0 a 100, CV de 0 a 27648. Tuning:
   KP 4, KI 0.27.
3. A PV é a entrada bruta e a CV a saída bruta: `PID LevelPID %IW64 %QW64 Setpoint`.
4. O botão em porcento para o setpoint: `SCP %IW66 0 27648 0 100 Setpoint`.

Experimente nas três linguagens: em texto estruturado `LevelPID.PID(PV := %IW64, SP := Setpoint,
CV => %QW64);`, em diagrama de blocos de função um bloco SCALE alimentando o pino SP do bloco PID. "Compare
languages" mostra a solução de referência em cada uma.

---
title: Dois tanques em série
simulation: two_tanks
level: 5
---
# 14. Dois tanques em série

**Objetivo:** manter o nível do tanque inferior 2 no setpoint. Você só pode abrir a entrada do
tanque superior 1 e a válvula entre os tanques: um processo lento com duas defasagens.

## Entradas e saídas (simulação Two tanks)

| Endereço | Dispositivo |
| --- | --- |
| %IW64 | Nível do tanque 1, 0-27648 = 0-100 % |
| %IW66 | Nível do tanque 2, 0-27648 = 0-100 % |
| %IW68 | Botão de setpoint, 0-27648 = 0-100 % |
| %QW64 | Válvula de entrada do tanque 1, 0-27648 = 0-100 % |
| %QW66 | Válvula de transferência entre os tanques, 0-27648 = 0-100 % |
| %I0.2, %I0.3, %I0.4 | Chaves de nível alto do tanque 1, alto do tanque 2, baixo do tanque 2 |

## Requisitos

1. O tanque 2 mantém o setpoint (±3 %) em até 3 minutos.
2. Ele volta ao setpoint depois que a saída do tanque 2 abre mais.
3. Ele segue um novo setpoint.
4. Nenhum dos tanques transborda.

## Pistas

- Um único PID do tanque 2 para a válvula de entrada funciona, mas lentamente. Uma **cascata** é melhor: o PID
  externo sobre o tanque 2 fornece o setpoint de um PID interno sobre o tanque 1 (o operando de malha mestre
  da instrução `PID`, ou ligue a CV de um PID no SP do outro em FBD).
- Defina a válvula de transferência com uma abertura fixa, por exemplo 60 % (`MOV 16589 %QW66`).
- Deixe cada PID escalar os valores brutos: PID Setup → Scaling, não escalada 0-27648.

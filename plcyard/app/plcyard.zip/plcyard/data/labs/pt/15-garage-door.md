---
title: Porta de garagem com fotocélula de segurança
simulation: garage
level: 3
symbols:
- %I0.0 Abrir (PB)
- %I0.1 Fechar (PB)
- %I0.2 Parada (NC, PB)
---
# 15. Porta de garagem com fotocélula de segurança

**Objetivo:** abrir e fechar uma porta com segurança: fins de curso, um botão de parada, uma fotocélula que
protege um carro no vão da porta, uma luz de advertência e uma luz de cortesia.

## Entradas e saídas (simulação Garage door)

| Endereço | Dispositivo |
| --- | --- |
| %I0.0 | Abrir (botão) |
| %I0.1 | Fechar (botão) |
| %I0.2 | Parada (botão, **normalmente fechado**) |
| %I0.3 | Fim de curso de aberta (porta totalmente para cima) |
| %I0.4 | Fim de curso de fechada (porta totalmente para baixo) |
| %I0.5 | Fotocélula: TRUE enquanto o feixe está livre |
| %Q0.0, %Q0.1 | Motor para cima, motor para baixo |
| %Q0.2 | Luz de advertência |
| %Q0.3 | Luz de cortesia |

## Requisitos

1. Abrir leva a porta para cima e para no fim de curso de aberta; Fechar leva-a para baixo até o fim de curso de fechada.
2. Parada detém a porta onde ela estiver.
3. Se o feixe for interrompido enquanto a porta está fechando, a porta volta a subir; Fechar não faz nada enquanto
   houver algo no vão da porta.
4. A luz de advertência pisca enquanto a porta se move.
5. A luz de cortesia fica acesa enquanto a porta se move e por alguns segundos depois que ela para.
6. O motor nunca continua empurrando contra um batente e nunca funciona nos dois sentidos ao mesmo tempo.

## Pistas

- Faça o selo de cada sentido como em um acionamento de motor; o sentido oposto e o fim de curso o interrompem.
- Lembre a "reversão" com um selo que o fim de curso de aberta limpa.
- Um temporizador autorreiniciável e uma comparação no seu acumulador fazem um pisca-pisca; um TOF mantém a luz de cortesia
  acesa.

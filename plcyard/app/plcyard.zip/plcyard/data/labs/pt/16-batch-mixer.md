---
title: Sequência de misturador em batelada
simulation: mixer
level: 5
symbols:
- %I0.0 Início (PB)
- %I0.1 Parada (NC, PB)
---
# 16. Sequência de misturador em batelada

**Objetivo:** uma sequência com etapas: encher dois ingredientes, misturar e aquecer, drenar, repetir.

## Entradas e saídas (simulação Batch mixer)

| Endereço | Dispositivo |
| --- | --- |
| %I0.0 | Início (botão) |
| %I0.1 | Parada (botão, **normalmente fechado**) |
| %I0.2, %I0.3, %I0.4 | Chaves de nível baixo (5 %), médio (50 %) e alto (90 %) |
| %IW64 | Temperatura, 0-27648 = 0-100 °C |
| %Q0.0, %Q0.1 | Válvula A, válvula B |
| %Q0.2 | Motor do misturador |
| %Q0.3 | Aquecedor |
| %Q0.4 | Válvula de dreno |
| %Q0.5 | Luz de batelada concluída |

## Requisitos

1. Início faz bateladas uma após a outra: pelo menos 2 em 2 minutos.
2. Toda batelada é boa: A até a chave média, B até a chave alta, misturada por pelo menos 5 s,
   drenada a 50-60 °C.
3. A luz de batelada concluída acende após cada batelada.
4. Sem transbordamento, sem aquecimento sem líquido, sem misturar um tanque vazio.
5. Parada desliga todas as saídas, e nada reinicia até Início.

## Pistas

- Guarde a etapa em uma tag inteira (0 parado, 1 encher A, 2 encher B, 3 misturar e aquecer, 4 drenar…). Cada
  saída é "etapa = n"; cada transição passa para a próxima etapa quando sua condição for verdadeira.
- Drene até o tanque esvaziar (a chave baixa desaciona, depois mais um pouco).
- Aqueça com histerese, por exemplo liga abaixo de 54 °C e desliga acima de 56 °C.

---
title: Ciclo de pega e coloca
simulation: pick_place
level: 4
symbols:
- %I0.0 Início (PB)
- %I0.1 Parada (NC, PB)
---
# 17. Ciclo de pega e coloca

**Objetivo:** um braço pneumático de dois eixos com garra de vácuo move peças da entrada para uma bandeja, um
ciclo após o outro, em uma ordem segura de movimentos.

## Entradas e saídas (simulação Pick and place)

| Endereço | Dispositivo |
| --- | --- |
| %I0.0 | Início (botão) |
| %I0.1 | Parada (botão, **normalmente fechado**) |
| %I0.2, %I0.3 | Braço no lado de pega, braço no lado de colocação (cilindro horizontal) |
| %I0.4, %I0.5 | Braço para cima, braço para baixo (cilindro vertical) |
| %I0.6 | Peça aguardando no ponto de pega |
| %I0.7 | Vácuo OK: a garra segura uma peça |
| %Q0.0 | Cilindro horizontal: avança para o lado de colocação |
| %Q0.1 | Cilindro vertical: para baixo |
| %Q0.2 | Vácuo |
| %Q0.3 | Lâmpada de ciclo |

Cada cilindro leva um segundo de ponta a ponta. Uma nova peça chega um segundo depois que a última
foi pega.

## Requisitos

1. Início executa ciclos enquanto chegam peças: desce, agarra, sobe, atravessa, desce, solta, sobe, volta. Pelo menos
   5 peças colocadas em um minuto.
2. Nenhuma peça é deixada cair fora da bandeja.
3. O braço nunca se move lateralmente enquanto está para baixo.
4. A lâmpada de ciclo fica acesa durante um ciclo.
5. Parada deixa o ciclo atual terminar com o braço de volta à posição inicial, e nenhum novo ciclo começa.

## Pistas

- Um número de etapa (0 inicial, 1 desce, 2 agarra, …) torna a sequência fácil de acompanhar; cada etapa espera
  seu sensor (braço para baixo, vácuo OK, braço para cima…) antes da próxima.
- Cada saída é uma lista de etapas: "para baixo" fica acionada nas etapas em que o braço desce ou permanece para baixo.
- Dê à soltura um temporizador curto (algumas centenas de ms) antes de levantar o braço.
- Somente a etapa inicial verifica Run: assim Parada encerra o trabalho após o ciclo atual.

---
title: Linha de enchimento e tampagem de garrafas
simulation: bottles
level: 4
symbols:
- %I0.0 Início (PB)
- %I0.1 Parada (NC, PB)
---
# 18. Linha de enchimento e tampagem de garrafas

**Objetivo:** uma esteira transporta garrafas sob um enchedor, um tampador e uma estação de inspeção; pare a
esteira em cada estação, e empurre as garrafas ruins para fora.

## Entradas e saídas (simulação Bottle line)

| Endereço | Dispositivo |
| --- | --- |
| %I0.0 | Início (botão) |
| %I0.1 | Parada (botão, **normalmente fechado**) |
| %I0.2 | Garrafa no enchedor |
| %I0.3 | Garrafa cheia (a garrafa no enchedor está em 95 % ou mais) |
| %I0.4 | Garrafa no tampador |
| %I0.5 | Garrafa na inspeção |
| %I0.6 | A garrafa na inspeção está boa |
| %Q0.0 | Esteira |
| %Q0.1 | Válvula de enchimento |
| %Q0.2 | Prensa do tampador |
| %Q0.3 | Empurrador de rejeição |
| %Q0.4 | Lâmpada de marcha |

Uma garrafa só permanece sob uma estação se a esteira parar enquanto o sensor da estação a vê. A
prensa precisa de meio segundo sobre uma garrafa para tampá-la. A cada cinco garrafas, uma recebe uma tampa ruim.

## Requisitos

1. Início executa a linha: pelo menos 8 garrafas boas expedidas em 2 minutos.
2. Nenhuma garrafa ruim é expedida.
3. Garrafas ruins são rejeitadas na inspeção; as boas não são.
4. Sem derramamento, sem transbordamento, sem tampar uma garrafa em movimento.
5. A lâmpada de marcha fica acesa enquanto a linha funciona.
6. Parada desliga a esteira, o enchedor, o tampador e a lâmpada de marcha.

## Pistas

- A esteira funciona a menos que uma estação esteja trabalhando: "enchendo" é uma garrafa no enchedor que ainda não está
  cheia; "tampando" é uma garrafa no tampador durante os primeiros 0.6 s (um TON no sensor).
- Encha somente enquanto a esteira estiver parada.
- O empurrador de rejeição é simplesmente "uma garrafa na inspeção que não está boa".

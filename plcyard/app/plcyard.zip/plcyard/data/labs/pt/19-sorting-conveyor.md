---
title: Classificação de caixas por tamanho
simulation: sorter
level: 5
symbols:
- %I0.0 Início (PB)
- %I0.1 Parada (NC, PB)
---
# 19. Classificação de caixas por tamanho

**Objetivo:** medir cada caixa com dois feixes de luz e empurrá-la para o compartimento do seu tamanho, mais adiante
na esteira, enquanto outras caixas já estão a caminho.

## Entradas e saídas (simulação Sorting conveyor)

| Endereço | Dispositivo |
| --- | --- |
| %I0.0 | Início (botão) |
| %I0.1 | Parada (botão, **normalmente fechado**) |
| %I0.2 | Caixa no ponto de medição |
| %I0.3 | Feixe baixo bloqueado (caixa média ou grande) |
| %I0.4 | Feixe alto bloqueado (caixa grande) |
| %I0.5, %I0.6, %I0.7 | Caixa em frente ao empurrador 1, 2, 3 |
| %Q0.0 | Esteira |
| %Q0.1, %Q0.2, %Q0.3 | Empurrador 1 (pequena), empurrador 2 (média), empurrador 3 (grande) |
| %Q0.4 | Lâmpada de marcha |

As caixas chegam pequena, grande, média, média, pequena, grande, … Uma caixa que chega ao fim da esteira
cai.

## Requisitos

1. Início executa a esteira: pelo menos 15 caixas classificadas em 90 segundos.
2. Toda caixa vai para o compartimento do seu tamanho.
3. Nenhuma caixa cai do fim da esteira.
4. A lâmpada de marcha fica acesa enquanto a esteira funciona.
5. Parada para a esteira e desliga a lâmpada de marcha.

## Pistas

- Várias caixas estão entre os feixes e os empurradores ao mesmo tempo, então lembre os tamanhos em ordem:
  uma fila (um array e um índice de escrita) para cada trecho da esteira.
- Quando uma nova caixa chega ao ponto de medição (borda de subida), seu tamanho é 1, ou 2 se o feixe baixo estiver
  bloqueado, ou 3 se o feixe alto também estiver bloqueado; escreva-o na fila do empurrador 1.
- Quando uma caixa chega ao empurrador k (borda de subida), leia o próximo tamanho da fila k: empurre-a se for
  tamanho k, caso contrário escreva-o na fila k+1.
- Endereços indexados funcionam em todo lugar: `Q1[W1]` em um MOV, um bloco MOVE ou texto estruturado.

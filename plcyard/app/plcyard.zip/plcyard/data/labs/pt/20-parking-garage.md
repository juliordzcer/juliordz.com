---
title: Cancelas e contador de estacionamento
simulation: parking
level: 3
symbols: []
---
# 20. Cancelas e contador de estacionamento

**Objetivo:** deixar os carros entrar e sair com duas cancelas, contá-los e mostrar as vagas livres; manter os carros
fora quando o estacionamento estiver cheio.

## Entradas e saídas (simulação Parking garage)

| Endereço | Dispositivo |
| --- | --- |
| %I0.0 | Carro aguardando na entrada |
| %I0.1 | Carro passando pela cancela de entrada (feixe) |
| %I0.2 | Carro aguardando na saída |
| %I0.3 | Carro passando pela cancela de saída (feixe) |
| %I0.4, %I0.5 | Cancela de entrada levantada, cancela de saída levantada |
| %Q0.0 | Levantar a cancela de entrada |
| %Q0.1 | Levantar a cancela de saída |
| %Q0.2 | Placa CHEIO |
| %QW4 | Visor de vagas livres (BCD) |

O estacionamento tem dez vagas e **três carros estão estacionados quando ele inicia**. Os carros chegam com os botões "Car
arrives" e "Car leaves" (ou com Traffic).

## Requisitos

1. O visor mostra as vagas livres desde o início (7).
2. Um carro aguardando na entrada recebe a cancela; ela desce quando o carro entrou.
3. Os carros que entram são contados no visor.
4. Um carro que sai recebe a cancela de saída e é contado.
5. CHEIO acende com dez carros dentro.
6. Com o estacionamento cheio, a cancela de entrada permanece abaixada para um carro aguardando.
7. Quando um carro sai, o carro aguardando entra.
8. Nenhuma cancela desce sobre um carro.

## Pistas

- Guarde o número de carros em uma tag inteira que começa em 3 (seu valor inicial na lista de tags).
- Faça o selo de "levantar" quando um carro aguarda (na entrada somente se houver vaga), desfaça o selo na borda
  de descida do feixe: é quando o carro passou, e o momento de contá-lo.
- Mostre `10 - count` com uma conversão BCD (TOD) na palavra do visor.

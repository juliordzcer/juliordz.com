---
title: Estação de bombas com rodízio de operação
simulation: pumps
level: 4
symbols:
- %I0.0 Reset de alarme (PB)
- %I0.1 Parada (NC, PB)
---
# 21. Estação de bombas com rodízio de operação

**Objetivo:** duas bombas esvaziam um poço de sucção. Elas se revezam para desgastar por igual, a segunda ajuda quando
o nível continua subindo, e uma bomba com falha é substituída pela outra.

## Entradas e saídas (simulação Pump station)

| Endereço | Dispositivo |
| --- | --- |
| %I0.0 | Reset de alarme (botão) |
| %I0.1 | Parada (botão, **normalmente fechado**) |
| %I0.2 | Nível baixo (15 % ou mais) |
| %I0.3 | Nível de partida (50 % ou mais) |
| %I0.4 | Nível alto (75 % ou mais) |
| %I0.5 | Nível de alarme de transbordamento (95 % ou mais) |
| %I0.6, %I0.7 | Falha da bomba 1, falha da bomba 2 (TRUE quando a proteção da bomba disparou) |
| %IW64 | Nível, 0-27648 = 0-100 % |
| %Q0.0, %Q0.1 | Bomba 1, bomba 2 |
| %Q0.2 | Lâmpada de alarme |

Cada bomba retira 3 % do poço por segundo. O controle deslizante de vazão de entrada vai até 5 % por segundo, mais
do que uma bomba consegue lidar.

## Requisitos

1. As bombas mantêm o nível entre baixo e alto: uma bomba parte no nível de partida e para no
   nível baixo.
2. Elas se revezam: cada novo ciclo de esvaziamento usa a outra bomba.
3. As duas bombas funcionam quando o nível continua subindo até o nível alto.
4. Uma bomba com falha é desligada e a outra assume.
5. A lâmpada de alarme acende por falha de bomba ou nível de transbordamento.
6. Reset limpa o alarme somente quando a falha desapareceu.
7. Sem transbordamento e sem bomba funcionando a seco.
8. Parada (mantida) desliga as duas bombas.

## Pistas

- Lembre qual bomba é líder em uma tag inteira (1 ou 2) e troque-a no início de cada ciclo:
  `Lead := 3 - Lead`.
- Um ciclo começa quando nenhuma bomba funciona e o nível de partida é atingido; ele termina no nível baixo.
- No nível alto, acione toda bomba que não estiver com falha.
- Faça o selo do alarme; desfaça-o com Reset somente quando não houver falha nem nível de transbordamento.

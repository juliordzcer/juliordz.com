---
title: Clima de ambiente com aquecimento e resfriamento
simulation: hvac
level: 5
symbols:
- %I0.0 Ligar (PB)
- %I0.1 Desligar (NC, PB)
---
# 22. Clima de ambiente com aquecimento e resfriamento

**Objetivo:** manter um ambiente na temperatura do botão de setpoint com um aquecedor e um resfriador, ambos
analógicos, nunca os dois ao mesmo tempo e nunca sem o ventilador.

## Entradas e saídas (simulação Room climate)

| Endereço | Dispositivo |
| --- | --- |
| %I0.0 | Sistema ligado (botão) |
| %I0.1 | Sistema desligado (botão, **normalmente fechado**) |
| %I0.2 | Janela aberta |
| %I0.3 | Fluxo de ar: o ventilador está funcionando |
| %IW64 | Temperatura do ambiente, 0-27648 = 0-50 °C |
| %IW66 | Botão de setpoint, 0-27648 = 0-50 °C |
| %Q0.0 | Ventilador |
| %Q0.1 | Lâmpada de aquecimento |
| %Q0.2 | Lâmpada de resfriamento |
| %QW64 | Aquecedor, 0-27648 = 0-100 % |
| %QW66 | Resfriador, 0-27648 = 0-100 % |

O ambiente começa a 16 °C com 8 °C do lado de fora. Aquecer ou resfriar sem o ventilador superaquece a serpentina
(a simulação ignora isso e o reporta); aquecer e resfriar ao mesmo tempo só desperdiça energia.

## Requisitos

1. Ligar aciona o ventilador e leva o ambiente ao setpoint (±0.5 °C) em até 2 minutos.
2. Ele mantém a temperatura (±1 °C) com a janela aberta e 18 °C do lado de fora.
3. Ele resfria quando está quente do lado de fora (35 °C), dentro de ±1 °C.
4. Ele segue um novo setpoint (24 °C) dentro de ±1 °C.
5. As lâmpadas de aquecimento e resfriamento mostram o que está funcionando.
6. Ele nunca aquece e resfria ao mesmo tempo, e nunca sem o ventilador.
7. Desligar para o ventilador, o aquecedor e o resfriador.

## Pistas

- Um único PID pode acionar ambos: deixe sua saída ir de -100 % (resfriamento total) a +100 % (aquecimento total)
  com o mínimo de saída da tag do PID definido em -100. O aquecedor recebe a parte positiva, o
  resfriador a parte negativa.
- Escale o ambiente e o setpoint para °C (0-27648 → 0-50) e as saídas de volta (0-100 % →
  0-27648).
- Sem fluxo de ar, sem aquecimento ou resfriamento: force a demanda para 0 quando o ventilador não estiver confirmado.

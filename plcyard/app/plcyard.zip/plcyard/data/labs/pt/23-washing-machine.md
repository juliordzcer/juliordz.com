---
title: Programa de máquina de lavar
simulation: washer
level: 5
symbols:
- %I0.0 Início (PB)
- %I0.1 Parada (NC, PB)
---
# 23. Programa de máquina de lavar

**Objetivo:** uma sequência temporizada com intertravamentos de segurança: travar a porta, encher, lavar girando nos dois sentidos,
drenar, centrifugar, esperar o tambor parar, destravar.

## Entradas e saídas (simulação Washing machine)

| Endereço | Dispositivo |
| --- | --- |
| %I0.0 | Início (botão) |
| %I0.1 | Parada (botão, **normalmente fechado**) |
| %I0.2 | Porta fechada |
| %I0.3 | Porta travada |
| %I0.4 | Água presente (10 % ou mais) |
| %I0.5 | Água cheia (80 % ou mais) |
| %I0.6 | Tambor parado |
| %Q0.0 | Trava da porta |
| %Q0.1 | Válvula de enchimento |
| %Q0.2, %Q0.3 | Lavar girando à esquerda, lavar girando à direita |
| %Q0.4 | Centrifugação |
| %Q0.5 | Bomba de dreno |
| %Q0.6 | Lâmpada de concluído |

O tambor acelera e desacelera a 400 rpm por segundo: após uma centrifugação ele leva alguns segundos para
parar.

## Requisitos

1. Início com a porta fechada executa uma lavagem completa em até 2 minutos.
2. As roupas giram na água por pelo menos 10 s em cada sentido.
3. A água é drenada antes de uma centrifugação de pelo menos 5 s.
4. A lâmpada de concluído acende no final.
5. Início não faz nada com a porta aberta.
6. Parada durante uma lavagem para o tambor e destrava a porta quando o tambor parou.
7. A porta nunca destrava enquanto o tambor gira, e a máquina nunca transborda.

## Pistas

- Um número de etapa: 0 parado, 1 travar, 2 encher, 3 lavar, 4 drenar, 5 centrifugar, 6 esperar o tambor, 7 concluído.
- Na etapa de lavagem, um temporizador de alguns segundos que se reinicia sozinho inverte o sentido.
- Drene até a chave "água presente" desacionar, depois mais um pouco.
- Parada salta para "esperar o tambor" a partir de qualquer etapa que acione algo.

---
title: Elevador de três andares
simulation: elevator
level: 5
symbols: []
---
# 24. Elevador de três andares

**Objetivo:** atender chamadas de pavimento e de cabine em três andares: memorizar cada chamada, deslocar-se até ela, parar nivelado
com o andar, abrir e fechar a porta com segurança.

## Entradas e saídas (simulação Elevator)

| Endereço | Dispositivo |
| --- | --- |
| %I0.0, %I0.1, %I0.2 | Botões de chamada de pavimento, andares 1-3 |
| %I0.3, %I0.4, %I0.5 | Botões da cabine, andares 1-3 |
| %I0.6, %I0.7, %I1.0 | Cabine no andar 1, 2, 3 |
| %I1.1 | Fim de curso de porta aberta |
| %I1.2 | Fim de curso de porta fechada |
| %I1.3 | Borda de segurança da porta livre (TRUE a menos que alguém esteja na passagem) |
| %I1.4 | Sobrepasse superior OK |
| %I1.5 | Sobrepasse inferior OK |
| %Q0.0, %Q0.1 | Motor para cima, motor para baixo |
| %Q0.2, %Q0.3 | Abrir porta, fechar porta |
| %Q0.4, %Q0.5, %Q0.6 | Lâmpadas de posição, andares 1-3 |

A cabine parte do andar 1 com a porta fechada. Percorre um andar em 3 s; a porta abre ou
fecha em 2 s.

## Requisitos

1. Uma chamada de pavimento traz a cabine e abre a porta nesse andar.
2. Um botão da cabine leva a cabine ao seu andar.
3. As chamadas são memorizadas (os botões são pressionados apenas por um instante) e todas são atendidas.
4. A porta reabre, ou permanece aberta, enquanto alguém estiver na passagem.
5. As lâmpadas de posição mostram o andar em que a cabine está.
6. A cabine nunca se move com a porta aberta, a porta nunca abre entre andares e nunca fecha
   sobre alguém.

## Dicas

- Trave um bit de chamada por andar a partir dos seus botões de pavimento e de cabine; limpe-o quando a porta estiver totalmente aberta
  nesse andar.
- Guarde o último andar que a cabine passou em uma tag inteira (ela começa em 1).
- "Aqui" é uma chamada no andar em que a cabine está; "acima" e "abaixo" são chamadas mais acima ou mais abaixo.
- Etapas: 0 ocioso, 1 abrindo, 2 aberta (espera), 3 subindo, 4 descendo, 5 fechando. Feche apenas enquanto
  a passagem estiver livre; se não estiver, abra novamente.

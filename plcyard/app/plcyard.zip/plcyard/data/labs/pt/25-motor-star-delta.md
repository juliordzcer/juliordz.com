---
title: Motor trifásico, estrela-triângulo, frente e ré
simulation: motor
level: 3
symbols:
- %I0.0 Frente (PB)
- %I0.1 Ré (PB)
- %I0.2 Parada (NC, PB)
- %I0.3 Relé de sobrecarga OK
- %I0.4 Motor parado
- %Q0.0 KM1 frente
- %Q0.1 KM2 ré
- %Q0.2 KM3 estrela
- %Q0.3 KM4 triângulo
- %Q0.4 Lâmpada de operação
- %Q0.5 Lâmpada de falha
---
# 25. Motor trifásico, estrela-triângulo, frente e ré

**Objetivo:** partir um motor trifásico em estrela e comutá-lo para triângulo, em qualquer sentido, protegido por
um relé de sobrecarga, como faz uma partida de motor real.

## Entradas e saídas (simulação Three-phase motor)

| Endereço | Dispositivo |
| --- | --- |
| %I0.0 | Frente (botão) |
| %I0.1 | Ré (botão) |
| %I0.2 | Parada (botão, **normalmente fechado**) |
| %I0.3 | Relé de sobrecarga OK (contato **normalmente fechado**: FALSE quando disparado) |
| %I0.4 | Motor parado (sensor de velocidade zero, abaixo de 30 rpm) |
| %Q0.0, %Q0.1 | Contator de linha KM1 frente, contator de linha KM2 ré |
| %Q0.2, %Q0.3 | KM3 estrela, KM4 triângulo |
| %Q0.4 | Lâmpada de operação |
| %Q0.5 | Lâmpada de falha |

## Requisitos

1. Frente parte o motor em estrela (KM1 + KM3) e comuta para triângulo (KM1 + KM4) alguns segundos
   depois; Ré faz o mesmo com KM2.
2. Nunca parte direto em triângulo.
3. Estrela e triângulo nunca ficam ligados juntos; frente e ré nunca ficam ligados juntos.
4. Ré é ignorada enquanto o motor gira em frente (e vice-versa): pare primeiro e
   parta no outro sentido só depois que o motor parar.
5. Parada para o motor.
6. Um disparo de sobrecarga desliga todos os contatores e acende a lâmpada de falha; o motor não pode partir até
   o relé ser rearmado.
7. A lâmpada de operação fica acesa enquanto o motor gira.

## Dicas

- Selar cada contator de linha como numa partida de motor; coloque Parada, o contato de sobrecarga e um contato
  NC do outro sentido em série.
- Só aceite uma partida enquanto "Motor parado" for TRUE.
- Um temporizador iniciado por qualquer um dos contatores de linha: estrela enquanto ele conta, triângulo quando
  termina, cada um com um contato NC do outro.

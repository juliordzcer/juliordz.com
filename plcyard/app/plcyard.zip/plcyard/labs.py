"""Practice exercises: markdown files with a small header (title, simulation, level, symbols)."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from .core.program import Program

DATA = Path(__file__).resolve().parent / "data"
ROOT = DATA / "labs"
SAMPLES = DATA / "samples"
LANGUAGES = ("LD", "ST", "FBD")


def _trio(ld: str, st: str, fbd: str) -> dict[str, str]:
    return dict(zip(LANGUAGES, (ld, st, fbd)))


def _sol(stem: str) -> dict[str, str]:
    return _trio(f"labs/solutions/{stem}.plcy", f"labs/solutions/{stem}.st.plcy", f"labs/solutions/{stem}.fbd.plcy")


def _smp(stem: str, ld: str = "") -> dict[str, str]:
    return _trio(f"samples/{stem}{ld}.plcy", f"samples/{stem}-st.plcy", f"samples/{stem}-fbd.plcy")


# The examples, each in ladder, structured text and function blocks (the same program in the three):
# key → (title, simulation, {language: file under data/}). The machine examples are the reference
# solutions of the exercises on that machine.
EXAMPLES = {
    "start-stop": ("Start/stop with seal-in", "io", _trio("samples/start-stop.plcy", "samples/start-stop-logic-st.plcy",
                                                           "samples/start-stop-logic-fbd.plcy")),
    "running-light": ("Start/stop with a delayed running light", "io", _trio("samples/start-stop-delay.plcy",
                                                                            "samples/start-stop-st.plcy", "samples/start-stop-fbd.plcy")),
    "timer-counter": ("Timer and counter", "io", _smp("timer-counter")),
    "motor-fb": ("Motor starters with a function block", "io", _smp("motor-starters-function-block")),
    "recipes": ("Recipes with a data type", "io", _trio("samples/recipes-data-type-ld.plcy", "samples/recipes-data-type.plcy",
                                                       "samples/recipes-data-type-fbd.plcy")),
    "silo": ("Silo filling line", "silo", _sol("08-silo-continuous")),
    "silo-modes": ("Silo with modes", "silo", _sol("09-silo-modes")),
    "silo-fb": ("Silo with a function block", "silo", _smp("silo-function-block")),
    "traffic-lights": ("Traffic lights", "traffic", _sol("10-traffic-light")),
    "traffic-routines": ("Traffic lights in routines", "traffic", _smp("traffic-lights-routines")),
    "tank-on-off": ("Tank level, on/off", "tank", _sol("11-tank-on-off")),
    "tank-pid": ("Tank level, PID", "tank", _trio("labs/solutions/12-tank-pid.plcy", "samples/tank-pid-structured-text.plcy",
                                                  "samples/tank-pid-fbd.plcy")),
    "tank-pid-scaled": ("Tank level, PID in engineering units", "tank", _sol("13-tank-pid-scaled")),
    "two-tanks": ("Two tanks, cascade PID", "two_tanks", _smp("two-tanks-cascade")),
    "garage": ("Garage door", "garage", _sol("15-garage-door")),
    "mixer": ("Batch mixer", "mixer", _sol("16-batch-mixer")),
    "elevator": ("Elevator", "elevator", _sol("24-elevator")),
    "bottles": ("Bottle line", "bottles", _sol("18-bottle-line")),
    "sorter": ("Sorting conveyor", "sorter", _sol("19-sorting-conveyor")),
    "pick-place": ("Pick and place", "pick_place", _sol("17-pick-and-place")),
    "parking": ("Parking garage", "parking", _sol("20-parking-garage")),
    "pumps": ("Pump station", "pumps", _sol("21-pump-station")),
    "hvac": ("Room climate", "hvac", _sol("22-room-climate")),
    "washer": ("Washing machine", "washer", _sol("23-washing-machine")),
    "motor": ("Three-phase motor, star-delta, forward and reverse", "motor", _smp("motor-star-delta")),
}
# keys of the earlier one-language examples (saved links, older pages) → (example, language)
EXAMPLE_ALIASES = {"start-stop-st": ("running-light", "ST"), "start-stop-fbd": ("running-light", "FBD"),
                   "silo-st": ("silo-modes", "ST"), "silo-fbd": ("silo-modes", "FBD"),
                   "traffic-st": ("traffic-lights", "ST"), "traffic-fbd": ("traffic-lights", "FBD"),
                   "tank-pid-st": ("tank-pid", "ST"), "tank-pid-fbd": ("tank-pid", "FBD"),
                   "motor-st": ("motor", "ST"), "motor-fbd": ("motor", "FBD")}


@dataclass
class Lab:
    id: str
    title: str
    simulation: str          # io | silo | traffic | tank
    level: int
    body: str
    symbols: dict[str, str] = field(default_factory=dict)
    path: Path | None = None

    def starter(self) -> Program:
        """Empty program with the exercise's symbols, so switches come wired."""
        p = Program.new()
        p.symbols = dict(self.symbols)
        return p

    @property
    def solution(self) -> Path | None:
        """Reference solution: labs/solutions/<same name as the exercise>.plcy."""
        if not self.path:
            return None
        return self.path.parent.parent / "solutions" / f"{self.path.stem}.plcy"

    @property
    def solutions(self) -> dict[str, Path]:
        """Reference solutions by language: LD, and ST / FBD when they exist (<name>.st.plcy, .fbd.plcy)."""
        if not self.path:
            return {}
        folder = self.path.parent.parent / "solutions"
        out = {"LD": self.solution}
        for lang in ("ST", "FBD"):
            f = folder / f"{self.path.stem}.{lang.lower()}.plcy"
            if f.exists():
                out[lang] = f
        return out


def parse(text: str, lab_id: str = "") -> Lab:
    head, body = {}, text
    symbols: dict[str, str] = {}
    if text.startswith("---"):
        _, raw, body = text.split("---", 2)
        key = None
        for line in raw.strip().splitlines():
            if line.startswith("- ") and key == "symbols":
                addr, _, desc = line[2:].strip().partition(" ")
                symbols[addr] = desc
            elif ":" in line:
                key, _, val = line.partition(":")
                key = key.strip()
                head[key] = val.strip()
    return Lab(lab_id, head.get("title", lab_id), head.get("simulation", "io"),
               int(head.get("level", 1)), body.strip(), symbols)


LANGS = ("en", "es", "pt", "fr", "it", "zh", "ar")


def load_all(lang: str = "en", root: Path = ROOT) -> list[Lab]:
    """The exercises in `lang`; one not translated yet comes in English. A translation keeps the English
    file name, so the reference solutions are shared."""
    labs = []
    for f in sorted((root / "en").glob("*.md")):
        tr = root / lang / f.name
        src = tr if lang != "en" and tr.exists() else f
        lab = parse(src.read_text(encoding="utf-8"), f.stem.split("-")[0])
        lab.path = src
        labs.append(lab)
    return labs

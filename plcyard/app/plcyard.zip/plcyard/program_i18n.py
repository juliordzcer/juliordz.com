"""Example programs in the reader's language: rung comments, ST comments, symbol texts and tag comments.

`data/programs_i18n/<lang>.json` maps the English text to its translation; text it lacks stays English.
Code, addresses, tag names and the NO / NC / PB markers that wire the I/O panel are never translated.
"""
from __future__ import annotations

import json
import re
from functools import lru_cache

from .labs import DATA

DIR = DATA / "programs_i18n"
_LINE = re.compile(r"//[ \t]*(.*?)[ \t]*$", re.M)
_BLOCK = re.compile(r"\(\*\s*(.*?)\s*\*\)", re.S)
ST_STARTER = "Write your program here."


@lru_cache
def table(lang: str) -> dict[str, str]:
    path = DIR / f"{lang}.json"
    return json.loads(path.read_text("utf-8")) if lang != "en" and path.exists() else {}


def tr(text: str, lang: str) -> str:
    return table(lang).get(text, text)


def texts(program) -> list[str]:
    """Every translatable text of a program, in order."""
    out = []
    for f in program.files.values():
        out += [r.comment for r in f.rungs] + [f.end_comment]
        if f.source:
            out += _LINE.findall(f.source) + _BLOCK.findall(f.source)
    out += list(program.symbols.values())
    out += [d.get("comment", "") for d in program.tags.values() if isinstance(d, dict)]
    return [t for t in out if t.strip()]


def _sub(m: re.Match, lang: str) -> str:
    inner = m.group(1)
    return m.group(0).replace(inner, tr(inner, lang), 1) if inner else m.group(0)


def localize(program, lang: str):
    """Translate the program's comments and symbol texts in place; returns it."""
    if not table(lang):
        return program
    for f in program.files.values():
        for r in f.rungs:
            r.comment = tr(r.comment, lang)
        f.end_comment = tr(f.end_comment, lang)
        if f.source:
            f.source = _LINE.sub(lambda m: _sub(m, lang), f.source)
            f.source = _BLOCK.sub(lambda m: _sub(m, lang), f.source)
    program.symbols = {a: tr(t, lang) for a, t in program.symbols.items()}
    for d in program.tags.values():
        if isinstance(d, dict) and d.get("comment"):
            d["comment"] = tr(d["comment"], lang)
    return program

"""Three-phase motor: a 4-pole induction motor (50 Hz, 1500 rpm synchronous, 10 A rated) with a
star-delta starter that can run it forward or in reverse, a thermal overload relay and a
zero-speed sensor.

Digital (slot words):
  %I0.0 Forward (NO)   %I0.1 Reverse (NO)   %I0.2 Stop (NC)
  %I0.3 Overload relay OK (NC contact 95-96: FALSE when tripped)   %I0.4 Motor stopped (< 30 rpm)
  %Q0.0 KM1 line contactor, forward   %Q0.1 KM2 line contactor, reverse   %Q0.2 KM3 star
  %Q0.3 KM4 delta   %Q0.4 Run lamp   %Q0.5 Fault lamp
Analog: AI0 motor current 0-10 V = 0-50 A, AI1 speed 0-10 V = 0-1500 rpm.
The motor turns with one line contactor and one of star or delta. In star it takes a third of the
current and torque, so start in star and switch to delta near full speed. Forward and reverse
together, or star and delta together, is a short circuit. A tripped overload relay opens the
contactor coils by its own wiring; it can be reset once it has cooled to 60 %.
"""

from __future__ import annotations

from dataclasses import dataclass, field

SYNC = 1500.0              # rpm
RATED_A = 10.0
LOCKED = 6.5               # locked-rotor current in delta, times the rated current
SLIP = 0.033               # slip at full load in delta (three times as much in star)
TAU = {"star": 1.2, "delta": 0.4}  # s to reach speed
COAST = 1.5                # s to coast down without load
STOPPED_RPM = 30.0
RESET_BELOW = 60.0         # % of the trip heat


@dataclass
class MotorModel:
    name = "Three-phase motor"
    load: float = 50.0                 # % of the rated torque, 0-150
    jammed: bool = False
    forward_pressed: bool = False
    reverse_pressed: bool = False
    stop_pressed: bool = False
    outputs: int = 0
    rpm: float = 0.0                   # signed: + forward, - reverse
    current: float = 0.0               # A
    heat: float = 0.0                  # % of the overload trip
    tripped: bool = False
    angle: float = 0.0
    starts: int = 0
    trips: int = 0
    shorts: int = 0
    peak: float = 0.0                  # A
    events: list[str] = field(default_factory=list)
    _powered: bool = False

    def out(self, bit: int) -> bool:
        return bool(self.outputs >> bit & 1)

    lamp = out

    @property
    def winding(self) -> str:
        """'star', 'delta' or '' as the contactors are now (a short counts as nothing)."""
        star, delta = self.out(2), self.out(3)
        return "star" if star and not delta else "delta" if delta and not star else ""

    @property
    def direction(self) -> int:
        f, r = self.out(0), self.out(1)
        return 1 if f and not r else -1 if r and not f else 0

    @property
    def powered(self) -> bool:
        return not self.tripped and self.direction != 0 and self.winding != ""

    def input_words(self) -> dict[int, int]:
        w = int(self.forward_pressed)
        w |= int(self.reverse_pressed) << 1
        w |= int(not self.stop_pressed) << 2
        w |= int(not self.tripped) << 3
        w |= int(abs(self.rpm) < STOPPED_RPM) << 4
        return {1: w}

    def set_output_words(self, words: dict[int, int]) -> None:
        self.outputs = words.get(2, 0) & 0xFFFF

    def analog_inputs(self) -> dict[int, float]:
        return {0: min(self.current, 50.0) / 5.0, 1: min(abs(self.rpm), SYNC) / SYNC * 10.0}

    def reset_overload(self) -> None:
        if not self.tripped:
            return
        if self.heat > RESET_BELOW:
            self._event("The overload relay is still too hot to reset")
        else:
            self.tripped = False

    def _event(self, text: str) -> None:
        if not self.events or self.events[-1] != text:
            self.events.append(text)

    def step(self, dt_ms: float) -> None:
        dt = dt_ms / 1000.0
        if self.out(0) and self.out(1) and not self.tripped:
            self.shorts += 1
            self._event("Forward and reverse contactors closed together: short circuit between phases")
        if self.out(2) and self.out(3) and not self.tripped and self.direction:
            self.shorts += 1
            self._event("Star and delta contactors closed together: short circuit")
        L = min(max(self.load, 0.0), 150.0) / 100.0
        powered, wind, d = self.powered, self.winding, self.direction
        if powered and not self._powered:
            self.starts += 1
            if wind == "delta" and abs(self.rpm) < SYNC / 2:
                self._event("Started straight in delta: the inrush current is about 6.5 times the rated current")
        if powered and d * self.rpm < -STOPPED_RPM:
            self._event("Reversed while the motor was still turning")
        self._powered = powered
        if powered:
            slip = SLIP * (3 if wind == "star" else 1)
            free = d * SYNC * (1 - slip * L)
            target = 0.0 if self.jammed else free
            dev = min(abs(free - self.rpm) / SYNC, 1.5)
            amps = RATED_A * ((0.35 + 0.65 * L) ** 2 + (LOCKED * dev) ** 2) ** 0.5
            self.current = amps / 3 if wind == "star" else amps
            tau = 0.05 if self.jammed else TAU[wind] * (1 + 0.5 * L)
        else:
            target, self.current = 0.0, 0.0
            tau = 0.05 if self.jammed else COAST / (1 + L)
        self.rpm += (target - self.rpm) * min(dt / tau, 1.0)
        if not powered and abs(self.rpm) < 5:
            self.rpm = 0.0
        self.angle = (self.angle + self.rpm * 6 * dt / 20) % 360     # drawn 20 times slower
        self.peak = max(self.peak, self.current)
        x = self.current / RATED_A
        self.heat = max(0.0, self.heat + dt * (0.5 * (x * x - 1) if x > 1.05 else -1.0))
        if self.heat >= 100.0 and not self.tripped:
            self.tripped, self.heat = True, 100.0
            self.trips += 1
            self._event("The overload relay tripped")
